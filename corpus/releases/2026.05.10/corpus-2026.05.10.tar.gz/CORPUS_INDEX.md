# Corpus Index

1240 entries total. Generated from corpus.jsonl.

| Name | id | Year | Corpus | IP | Draft |
|---|---|---|---|---|---|
| 10x Genomics Chromium controller and Next GEM chip | `10x-genomics-chromium-controller` | 2016 | private | patented |  |
| 10x Genomics Visium HD spatial transcriptomics slide | `10x-genomics-visium-hd` | 2023 | private | patented |  |
| 10x Genomics Visium HD with CytAssist | `10x-visium-hd-cytassist` | 2023 | private | patented |  |
| 10x Genomics Xenium Prime 5K | `10x-xenium-prime-5k` | 2024 | private | patented |  |
| 1CellBio inDrop Commercial Reagent System | `1cellbio-indrops-commercial-extension` | 2017 | private | patented | ✓ |
| 1CellBio inDrop platform (commercial inDrops) | `1cellbio-indrops-commercial` | 2016 | private | patented |  |
| 2-methacryloyloxyethyl phosphorylcholine (MPC) polymer for non-fouling surfaces | `lee-1989-mpc-polymer-passivation` | 1989 | academic | patented |  |
| 23andMe Oragene Saliva Collection Tube | `23andme-saliva-collection-tube` | 2007 | private | patented |  |
| 3D Bioprinting Solutions FABION Multi-Material Bioprinter | `3d-bioprinting-solutions-fabion` | 2014 | private | patented |  |
| 3D Systems MJP / ProJet MultiJet UV/Wax Inkjet 3D Printer | `3d-systems-mjp-projet-multijet` | 2003 | private | patented | ✓ |
| 3D-printed microfluidic valves and pumps | `kong-2017-3d-printed-microfluidic-valves` | 2017 | academic | open-permissive |  |
| 3DuF — Interactive Design Environment for Continuous-Flow Microfluidic Devices | `sanka-2019-3duf-interactive-design` | 2019 | open | open-permissive |  |
| 3M (now Neogen) Petrifilm food microbiology plates | `3m-petrifilm-rapid-detect` | 1980 | private | patented |  |
| 3M / Solventum Hollow Microstructured Transdermal System (hMTS) | `3m-hollow-microneedle-patch` | 2008 | private | patented |  |
| 3M Petrifilm Plate Reader (Advanced) | `3m-petrifilm-plate-reader-vision` | 2007 | private | patented |  |
| 454 Life Sciences PicoTiterPlate sequencing | `margulies-2005-454-picotiterplate` | 2005 | academic | patented |  |
| 908 Devices REBEL Single-Cell Metabolomics Cell Culture Analyzer | `908-devices-rebel` | 2020 | private | patented |  |
| 908 Devices ZipChip Capillary Electrophoresis-MS Interface | `908-devices-zipchip` | 2015 | private | patented |  |
| A BioMEMS review: MEMS technology for physiologically integrated devices | `grayson-2004-bioMEMS-survey` | 2004 | academic | public-domain |  |
| Abaxis VetScan VS2 veterinary clinical chemistry analyzer | `abaxis-vetscan-vs2` | 1995 | private | patented |  |
| Abbott Alinity c Clinical Chemistry Analyzer Cuvette Wheel | `abbott-alinity-c-clinical-chemistry-fluidics` | 2017 | private | patented |  |
| Abbott Alinity i Immunoassay Analyzer Fluidic Subsystem | `abbott-alinity-i-immunoassay-fluidics` | 2017 | private | patented |  |
| Abbott Alinity m Molecular Diagnostics Sample-to-Result Cartridge | `abbott-alinity-m-molecular-cartridge` | 2017 | private | patented |  |
| Abbott ARCHITECT i2000/i2000SR immunoassay analyzer cartridge | `abbott-architect-i2000` | 2003 | private | patented |  |
| Abbott BinaxNOW COVID-19 Antigen Self Test (OTC) | `abbott-binaxnow-self-test-otc-2021` | 2021 | private | patented |  |
| Abbott BinaxNOW rapid antigen test cassette | `abbott-binaxnow-rapid-antigen` | 1996 | private | patented |  |
| Abbott Cell-Dyn Sapphire Hematology Optical/Impedance Flow Cell | `abbott-cell-dyn-sapphire-flow-cell` | 2003 | private | patented |  |
| Abbott FreeStyle Libre continuous glucose monitor | `abbott-freestyle-libre-cgm` | 2014 | private | patented |  |
| Abbott FreeStyle Navigator Continuous Glucose Monitor | `abbott-freestyle-navigator-cgm` | 2008 | private | patented |  |
| Abbott i-STAT Alinity Handheld Blood Analysis Cartridge | `abbott-istat-alinity-cartridge` | 2018 | private | patented |  |
| Abbott ID NOW isothermal amplification cartridge | `abbott-id-now-isothermal-cartridge` | 2014 | private | patented |  |
| Abbott Piccolo Xpress / Abaxis disc-format clinical chemistry analyzer | `abbott-piccolo-xpress` | 1995 | private | patented |  |
| ABEC Custom Single-use Bioreactor (CSR) / Custom Stainless Steel Bioreactor (CSSB) | `abec-cssb-custom-stainless-bioreactor` | 2013 | private | patented |  |
| Aber Instruments Incyte (Hamilton Incyte) Capacitance Probe | `aber-incyte-capacitance-probe` | 2008 | private | patented |  |
| ABI 3130xl Genetic Analyzer | `abi-3130xl-ce` | 2003 | private | patented |  |
| AcouSort AcouSep | `acousort-acousep-blood-separator` | 2019 | private | patented |  |
| AcouSort AcouTrap | `acousort-acoutrap-cell-retention` | 2018 | private | patented |  |
| AcouSort AcouWash | `acousort-acouwash-buffer-exchange` | 2020 | private | patented |  |
| AcouSort BAW acoustofluidic platform | `acousort-acoustofluidic-platform` | 2013 | private | patented |  |
| Acoustic-streaming microvortex cell trap | `hou-2013-acoustic-cell-trapping` | 2009 | academic | patented |  |
| Acoustic-streaming sharp-edge cell trap | `hou-2012-acoustic-vortex-cell-trap` | 2013 | academic | patented |  |
| Acoustically detectable cellular-level lung injury model | `huh-2007-lung-on-chip-precursor` | 2007 | academic | public-domain |  |
| Adrian Tchaikovsky Children of Time uplift nanovirus delivery system | `tchaikovsky-children-of-time-nanovirus` | 2015 | fictional | fictional |  |
| Adrian Tchaikovsky Final Architecture autodoc / shipboard medical | `tchaikovsky-final-architecture-autodoc` | 2021 | fictional | fictional |  |
| Adva Biotechnology AdvaBio bioreactor | `adva-biotechnology-advabio` | 2018 | private | patented |  |
| Advanced Instruments / Solentim VIPS PRO single-cell deposition system | `solentim-vips` | 2017 | private | patented |  |
| Advanced Liquid Logic / Illumina NeoPrep digital microfluidics | `advanced-liquid-logic-illumina-dmf` | 2007 | private | patented |  |
| Advanced Solutions BioAssemblyBot 6-Axis Bioprinter | `advanced-solutions-bioassemblybot` | 2014 | private | patented |  |
| Advion expression CMS Compact Mass Spectrometer | `advion-expression-cms` | 2010 | private | patented |  |
| Advion TriVersa NanoMate chip-ESI source | `advion-triversa-nanomate` | 2003 | private | patented |  |
| Aerosint Selective Multi-Powder Deposition Recoater | `aerosint-selective-powder-deposition` | 2016 | private | patented |  |
| AESOP: acoustic-electric shear orbiting poration | `zhang-2026-aesop-acoustic-electric-poration` | 2026 | academic | patented |  |
| AfaSci-style Wearable Cortisol Sensor (sweat cortisol aptamer wearable, multi-author) | `afasci-wearable-cortisol` | 2018 | academic | unknown |  |
| Agilent HPLC-Chip / MS Chip Cube | `agilent-hplc-chip` | 2005 | private | patented |  |
| Agilent Magnis NGS Prep System | `siemens-magnis-dx-ngs-prep` | 2019 | private | patented |  |
| Air Products microchannel hydrocarbon-to-hydrogen bench reactor (microHCBR) | `air-products-microhcbr-hydrogen-reactor` | 2003 | private | patented |  |
| Akatsuki LAC (Lightning and Airglow Camera) and IR1 | `akatsuki-lac-lightning-airglow-camera` | 2010 | private | unknown |  |
| Akira Tetsuo mutation containment chamber | `akira-tetsuo-mutation-chamber` | 1982 | fictional | fictional |  |
| Akoya Biosciences PhenoCycler-Fusion | `akoya-phenocycler-fusion` | 2022 | private | patented |  |
| Akoya CODEX Athena (Imaging Bay Update) | `akoya-codex-athena-cytassist-2024` | 2024 | private | patented | ✓ |
| Akoya CODEX Athena (PhenoImager Athena) | `akoya-codex-athena` | 2024 | private | unknown | ✓ |
| Aldevron Plasmid Manufacturing Platform (Danaher subsidiary) | `aldevron-plasmid-extend` | 1998 | private | patented |  |
| Alfa Laval ART Plate Reactor (Reaction Technology) | `alfa-laval-art-plate-reactor` | 2008 | private | patented |  |
| Aliens autonomous med pod (Prometheus) | `aliens-med-pod` | 2012 | fictional | fictional |  |
| ALine integrated multilayer flow cells (laminate microfluidics) | `aline-integrated-flowcell` | 2010 | private | patented |  |
| Alita Battle Angel cyborg-body diagnostic and assembly | `alita-battle-angel-cyborg-medbay` | 2019 | fictional | fictional |  |
| Allevi 6 multi-material bioprinter | `allevi-6-bioprinter` | 2014 | private | patented |  |
| AM4Pharma Semisolid 3D Pharmaceutical Printer | `am4pharma-semisolid-3d-printer` | 2020 | private | patented | ✓ |
| AmAr Equipments continuous-flow microreactor skid | `amar-equipments-microreactor-skid` | 2014 | private | unknown | ✓ |
| AMTechnology Coflore ATR oscillatory baffled flow reactor | `amtechnology-coflore-atr` | 2010 | private | patented |  |
| An experimental investigation of the circumstances which determine flow regime | `reynolds-1883-pipe-flow-transition` | 1883 | academic | public-domain |  |
| AncestryDNA Saliva Collection Tube | `ancestry-saliva-collection-kit` | 2012 | private | patented |  |
| ANDE 6C Rapid DNA Identification System | `ande-6c-rapid-dna` | 2014 | private | patented |  |
| ANDE 6C Rapid DNA System | `ande-6c-rapid-dna-cartridge` | 2014 | private | patented |  |
| Andelyn Biosciences AAV Manufacturing Platform | `andelyn-biosciences-aav` | 2020 | private | trade-secret | ✓ |
| Andrew Alliance / Andrew+ Scriptable Pipetting Robot | `evastreams-andrew-alpha-script` | 2014 | open | patented |  |
| Andrew Alliance Andrew+ pipetting robot | `andrew-pipetting-robot` | 2014 | private | patented |  |
| Andromeda Strain Wildfire facility microfluidic detail | `andromeda-strain-wildfire-detail` | 1969 | fictional | fictional |  |
| ANGLE Parsortix Cell Capture Cassette | `angle-parsortix-wearable-thought` | 2012 | private | patented |  |
| Ann Leckie Imperial Radch medical units / ancillary maintenance fluidics | `leckie-imperial-radch-medical` | 2013 | fictional | fictional |  |
| Annalee Newitz Autonomous open-pharma piracy infrastructure | `newitz-autonomous-pharma-pirate` | 2017 | fictional | fictional |  |
| Annalee Newitz The Terraformers terraforming biological-platform infrastructure | `newitz-terraformers-bio-platform` | 2023 | fictional | fictional |  |
| Annihilation Southern Reach decontamination / containment fluidics | `annihilation-area-x-decontamination` | 2014 | fictional | fictional |  |
| Ansa Biotechnologies Enzymatic DNA Synthesis Platform | `ansa-biotechnologies-enzymatic-synthesis` | 2023 | private | patented | ✓ |
| Anzalone–Pearce 2013 Open-Source Colorimeter (Michigan Tech MOST) | `anzalone-pearce-2013-open-colorimeter` | 2013 | open | open-copyleft |  |
| ApoCell ApoStream CTC Capture System | `apocell-apostream-ctc-dep` | 2012 | private | patented |  |
| Applied Biosystems 3500xL Genetic Analyzer (CE Capillary Array) | `thermofisher-3500xl-genetic-analyzer-ce` | 2010 | private | patented |  |
| Applied Biosystems 7500 Real-Time PCR System | `abi-7500-real-time-pcr` | 2005 | private | patented |  |
| Applikon ez-Control + my-Control Bioreactor Controllers | `applikon-ez-control-bioreactor` | 2013 | private | patented |  |
| Aprecia Spritam (3D-Printed Levetiracetam) | `aprecia-spritam-3d-printed-levetiracetam` | 2015 | private | patented |  |
| Arkray Spotchem EZ SP-4430 Dry-Chemistry Analyzer | `arkray-spotchem-ez-dry-strip` | 2003 | private | patented |  |
| ARROW liquid-core optical waveguide on chip | `schmidt-hawkins-arrow-waveguide` | 2004 | academic | patented |  |
| Arthur C. Clarke 2001 hibernation chamber fluid management | `clarke-2001-hibernation-chamber` | 1968 | fictional | fictional |  |
| Asahi Kasei Microsep / Cation MS Flow Electrolysis Cell | `asahi-kasei-microsep-cation-electrolyzer` | 2010 | private | patented |  |
| Asahi Kasei Planova S20N continuous virus filter | `asahi-kasei-planova-s20n` | 2018 | private | patented |  |
| Aseptic Technologies Crystal Closed Vial / AT-Closed Vial | `aseptic-technologies-crystal-closed-vial` | 2008 | private | patented |  |
| Asia-Pacific organ-on-chip programs (Taiwan, Korea, Singapore consortia) | `taiwan-tw-organ-chip-research` | 2018 | academic | patented |  |
| Aspara CRISPR-based Detection Cartridge | `aspara-crispr-detection-cartridge` | 2022 | private | patented | ✓ |
| Aspect Biosystems RX1 Lab-on-a-Printer microfluidic bioprinter | `aspect-biosystems-rx1` | 2014 | private | patented |  |
| Aspect Biosystems RX1 Microfluidic Printhead (head specifically) | `aspect-biosystems-rx1-microfluidic-printhead` | 2015 | private | patented |  |
| Aspendia cardiac POC cartridge (sub-femtomolar troponin) | `aspendia-cardiac-cartridge` | 2021 | private | patented |  |
| Asynt fReactor multi-stage CSTR flow reactor | `asynt-freactor` | 2015 | private | patented |  |
| Autobio Diagnostics rapid test cartridge family | `autobio-rapid-test` | 2010 | private | patented |  |
| Avantium Flowrence high-throughput parallel microreactor system | `avantium-flowrence-parallel-microreactor` | 2006 | private | patented |  |
| Azenta (Brooks) GENEWIZ NGS sample-prep cartridges | `azenta-brooks-cartridges` | 2019 | private | trade-secret | ✓ |
| Babylon 5 Centauri medical sleeper pod | `babylon5-centauri-medical-pods` | 1995 | fictional | fictional | ✓ |
| Babylon 5 Medlab automated diagnostic and treatment beds (Dr. Franklin's lab) | `babylon5-medlab-autodoc` | 1994 | fictional | fictional |  |
| Babylon 5 Narn biological weapons / Dilgar War medical-weapon labs | `babylon5-narn-bioweapon-facility` | 1995 | fictional | fictional | ✓ |
| Babylon 5 Vorlon encounter suit biological life-support | `babylon5-vorlon-encounter-suit` | 1993 | fictional | fictional | ✓ |
| Backyard Brains SpikerBox open neuroscience hardware | `backyard-brains-spikerbox` | 2011 | open | open-permissive |  |
| Baltimore Underground Science Space (BUGSS) | `bugss-baltimore-underground` | 2012 | open | open-permissive |  |
| Barcoded hydrogel beads for single-cell RNA-seq | `rotem-zilionis-2015-barcoded-bead` | 2015 | academic | public-domain |  |
| Battlestar Galactica Cylon Centurion organic-fluid circulation system | `bsg-cylon-centurion-fluid-circulation` | 2003 | fictional | fictional | ✓ |
| Battlestar Galactica Cylon Hybrid immersion tank (basestar control Hybrid) | `bsg-cylon-hybrid-tank` | 2006 | fictional | fictional |  |
| Battlestar Galactica Cylon resurrection tank (re-imagined series) | `bsg-cylon-resurrection-tank` | 2004 | fictional | fictional |  |
| Battlestar Galactica Galactica sickbay (Doc Cottle's bay) | `bsg-galactica-sickbay-cottle` | 2003 | fictional | fictional |  |
| Battlestar Galactica medbay (Galactica + Cylon variants) | `bsg-medbay-cylons` | 2003 | fictional | fictional |  |
| Bayanihan FoodLab — Philippine Community Food Microbiome Lab | `bayanihan-foodlab-philippines` | 2020 | open | open-permissive | ✓ |
| BD BACTEC FX Blood Culture Bottle Fluorescence Detection (referenced; predominantly BD product) | `biomerieux-bactec-fx-bottle-fluorescence` | 2008 | private | patented |  |
| BD FACSChorus Clinical Workstation | `bd-facschorus-clinical-software` | 2018 | private | patented | ✓ |
| BD FACSDiscover S8 Imaging Cell Sorter | `bd-facsdiscover-s8-imaging-sorter` | 2022 | private | patented |  |
| BD Rhapsody single-cell analysis system | `bd-rhapsody-microwell` | 2017 | private | patented |  |
| BD Veritor rapid test platform | `bd-veritor-rapid-test` | 2011 | private | patented |  |
| BD Veritor System cartridge | `bd-veritor-cartridge` | 2010 | private | patented |  |
| Be The Match BioTherapies / NMDP Process Development | `be-the-match-biocenter-biotrust` | 2015 | private | trade-secret | ✓ |
| Bead-based cell capture in microfluidic channels | `yu-2010-cell-pull-down-bead` | 2007 | academic | patented |  |
| Beam Therapeutics Base-Editing Manufacturing Platform | `beam-therapeutics-base-editing-mfg` | 2019 | private | patented |  |
| Beckman Biomek i5 / i7 automated workstation | `beckman-biomek-iseries` | 2016 | private | patented |  |
| Beckman Coulter AU/DxC clinical chemistry analyzer | `beckman-coulter-au-flow-cell` | 2003 | private | patented |  |
| Beckman Coulter AU5800 Clinical Chemistry Analyzer Cuvette Wheel | `beckman-coulter-au5800-cuvette-wheel` | 2011 | private | patented |  |
| Beckman Coulter CytoFLEX SRT Cell Sorter | `beckman-cytoflex-srt-microfluidic-sort` | 2020 | private | patented |  |
| Beckman Coulter DxH 900 Hematology VCSn Flow Cell | `beckman-coulter-dxh-900-flow-cell` | 2017 | private | patented |  |
| Beckman Coulter DxI 9000 Access Immunoassay Reaction Vessel Track | `beckman-coulter-dxi-9000-immunoassay` | 2021 | private | patented |  |
| Beckman Vi-CELL XR Cell Viability Trypan Blue Cuvette | `beckman-vi-cell-xr-cell-viability-cuvette` | 2003 | private | patented |  |
| Becky Chambers Wayfarer medbay | `chambers-wayfarer-medbay` | 2014 | fictional | fictional |  |
| Behrens et al. 2020 Open-Source 3D-Printed Peristaltic Pump | `behrens-2020-3d-printed-peristaltic-pump` | 2020 | open | open-permissive |  |
| Bento Bioworks Bento Lab portable PCR + electrophoresis | `bento-bio-engineer` | 2016 | open | open-permissive |  |
| Bento Lab Portable PCR + Centrifuge + Gel Workstation | `bento-lab-portable-pcr-bento-bio` | 2016 | open | patented |  |
| Berkeley Lights Beacon (PhenomeX, now Bruker) optofluidic platform | `phenomex-beacon-bli` | 2016 | private | patented |  |
| Berkeley Lights Beacon (PhenomeX/Bruker) | `berkeley-lights-beacon-optofluidic` | 2016 | private | patented |  |
| Berkeley Lights Beacon optofluidic platform | `berkeley-lights-beacon` | 2016 | private | patented |  |
| Berkeley Lights Lightning Optofluidic System | `berkeley-lights-lightning` | 2019 | private | patented |  |
| Beta Bionics iLet Bionic Pancreas | `beta-bionics-ilet-bionic-pancreas` | 2014 | private | patented |  |
| BGI / MGI cartridge product family extensions | `bgi-mgi-cartridge-extensions` | 2017 | private | patented |  |
| BGI MGI DNBSEQ sequencer flow cell | `bgi-mgi-dnbseq-flowcell` | 2010 | private | patented |  |
| Bhattacharjee 2016 3D-Printed Microfluidics Toolkit | `bhattacharjee-2016-3d-printed-microfluidics` | 2016 | academic | open-permissive |  |
| BICO BIO X Pneumatic / Thermoplastic / Photocuring Printhead Family (extended) | `bico-bio-x-pneumatic-printhead-extended` | 2017 | private | patented |  |
| BICO BIO X6 Six-Tool Bioprinter | `bico-bio-x6-six-tool-bioprinter` | 2019 | private | patented |  |
| BICO Group bio-convergence platform portfolio | `bico-group-umbrella` | 2016 | private | patented | ✓ |
| BICO INKREDIBLE / INKREDIBLE+ Bioprinter (historical) | `bico-inkredible-bioprinter-historical` | 2016 | private | patented |  |
| BillionToOne UNITY cfDNA Prep Cartridge | `billiontoone-unity-cfdna-prep` | 2020 | private | patented |  |
| Bio-Rad Gene Pulser MXcell Electroporation System | `biorad-gene-pulser-mxcell` | 2007 | private | patented |  |
| Bio-Rad QX Droplet Digital PCR system | `bio-rad-qx-ddpcr-system` | 2011 | private | patented |  |
| Bio-Rad TC20 / TC10 automated cell counter | `biorad-nanocoulter-bead-counter` | 2010 | private | patented |  |
| Bio-Rad TC20 Automated Cell Counter | `biorad-tc20-cell-counter` | 2013 | private | patented |  |
| Bio-Techne / ProteinSimple Simple Western (capillary western) | `proteinsimple-westernblot-simple-western` | 2011 | private | patented |  |
| BioBlaze Community Bio Lab — Chicago DIY Biology | `bioblaze-chicago-community-lab` | 2018 | open | open-permissive |  |
| BioCurious community biology lab | `biocurious-community-lab` | 2010 | open | open-permissive |  |
| BioFire FilmArray multiplex PCR cartridge | `biofire-filmarray-multiplex-pcr-cartridge` | 2008 | private | patented |  |
| Biolinq Intradermal Microneedle CGM Patch | `biolinq-intradermal-microneedle-cgm` | 2019 | private | patented |  |
| BiologiGaragen (Copenhagen Community Lab) | `biologigaragen-copenhagen` | 2014 | open | open-permissive |  |
| BioMAKE community biology hardware repository | `biomake-uchicago` | 2018 | open | open-permissive |  |
| BioMEMS overview (Madou 1997) | `madou-1997-bioMEMS-survey` | 1997 | academic | public-domain |  |
| bioMerieux NucliSENS easyMAG / EMAG | `biomerieux-easymag-emag` | 2007 | private | patented |  |
| bioMérieux GENE-UP Real-Time PCR Pathogen Detection | `biomerieux-gene-up-pcr-pathogen` | 2014 | private | patented |  |
| bioMérieux VIDAS 3 Solid Phase Receptacle (SPR) Immunoassay Cone | `biomerieux-vidas-3-spr-cone` | 1990 | private | patented |  |
| bioMérieux VIDAS UP Salmonella (SPT) Phage Recombinant Assay | `biomerieux-vidas-salmonella-easy` | 2012 | private | patented |  |
| bioMérieux VITEK 2 Microbial ID/AST Test Card Fluidic Wells | `biomerieux-vitek-2-card-fluidics` | 2002 | private | patented |  |
| Bionano Genomics Saphyr optical genome mapping | `nanofluidics-bionano-saphyr` | 2017 | private | patented |  |
| Biosafe SmartMax Closed Cell Therapy Cryopreservation / Fill | `biosafe-smartmax-small-volume-fill` | 2010 | private | patented |  |
| BioServe Lab-on-Chip Application Development (LOCAD) ISS Cartridge | `bioserve-loca-iss-cartridge` | 2006 | academic | unknown |  |
| BioShock plasmid / EVE injection vials and Gene Banks | `bioshock-plasmid-injection` | 2007 | fictional | fictional |  |
| BioShock Plasmid bottling plant / Adam-Eve production facility | `bioshock-plasmid-bottling-plant` | 2007 | fictional | fictional |  |
| BioShock Vita-Chamber player resurrection device | `bioshock-vita-chamber` | 2007 | fictional | fictional |  |
| Biotech Without Borders — NYC Community DIY-Bio Lab | `biotech-without-borders-nyc` | 2017 | open | open-permissive |  |
| BioTek MultiFlo FX dispenser | `biotek-multiflo-flx-dispenser` | 2010 | private | patented |  |
| Black Hole Lab academic microfluidics tooling | `black-hole-lab-foundry` | 2015 | open | open-permissive |  |
| Black Mirror neural-fluid implant depictions | `black-mirror-blockchain-implant` | 2016 | fictional | fictional |  |
| Blackrock Microsystems Utah Intracortical Electrode Array | `blackrock-utah-array` | 1991 | private | patented |  |
| BLAME! Killy bioassembler / Net Sphere medical apparatus | `blame-net-sphere-bioassembly` | 1997 | fictional | fictional |  |
| Blood-brain barrier-on-chip | `booth-kim-2012-bbb-on-chip` | 2012 | academic | public-domain |  |
| Blood-on-a-chip review (Toner & Irimia 2005) | `toner-irimia-2005-blood-on-chip` | 2005 | academic | public-domain |  |
| BlueSens BlueInOne Cell Off-Gas Analyzer | `bluesens-blueinone-offgas` | 2008 | private | patented |  |
| BlueSens BlueInOne FERM Off-Gas Analyzer | `bluesens-blueinone-ferm-offgas` | 2010 | private | patented |  |
| BMF Material microArch P150 / P130 projection micro-stereolithography printer | `bmf-microarch-p150` | 2016 | private | patented |  |
| BongoPump Open Liquid-Handling Pump | `open-bioworks-bongo-pump` | 2022 | open | open-permissive | ✓ |
| Boom guanidinium-silica nucleic acid extraction | `boom-1990-silica-magnetic-extraction` | 1990 | academic | patented |  |
| Boyden chamber chemotaxis assay | `boyden-1962-chamber-chemotaxis` | 1962 | academic | public-domain |  |
| Brave New World Bokanovsky-process embryo hatchery | `brave-new-world-bokanovsky-process` | 1932 | fictional | fictional |  |
| Brother GTX/GTX600 Direct-to-Garment Printer | `brother-gtx-direct-to-garment-printer` | 2017 | private | patented |  |
| Brother Industries Thin-Film Piezo Inkjet Printhead | `brother-piezo-printhead-thin-film` | 1996 | private | patented | ✓ |
| Bruce Sterling Schismatrix Shaper genetic-engineering clinics | `sterling-schismatrix-shaper-clinics` | 1985 | fictional | fictional |  |
| Bruker Avance Neo / Fourier 80 In-Line NMR PAT | `bruker-avance-neo-process-nmr` | 2018 | private | patented |  |
| Bruker CellScape (Canopy Biosciences) | `bruker-cellscape-spatial-proteomics` | 2020 | private | patented |  |
| Bruker MATRIX-MF In-Line FTIR PAT Spectrometer | `bruker-matrix-mf-ftir-pat` | 2010 | private | patented |  |
| Bruker Microflex MALDI-TOF Benchtop Mass Spectrometer | `bruker-microflex-maldi-tof` | 2003 | private | patented |  |
| Buehner / Hill 1977 IBM Thermal Inkjet Research Disclosure | `buehner-hill-1977-ibm-thermal-inkjet-research` | 1977 | academic | open-permissive |  |
| Burstein/Tecan LabCD original disc-format platform | `tecan-burstein-labcd` | 1997 | private | patented |  |
| C. J. Cherryh Cyteen azi production facility (Reseune azi vats) | `cherryh-cyteen-azi-production` | 1988 | fictional | fictional |  |
| Caliper LabChip / ACLA chip technology (acquired by Ciba-Geigy lineage) | `caliper-acla-chip-1999` | 1996 | private | patented |  |
| Cambridge / Imperial College DEP-on-CMOS Single-Cell Chip | `cambridge-imperial-dep-on-cmos-2020` | 2020 | academic | open-permissive |  |
| Cambridge Reactor Design Polar Bear and Polar Bear Plus flow chemistry chiller | `cambridge-reactor-design-polar-bear-plus` | 2010 | private | patented |  |
| Camena Bioscience gSynth Enzymatic DNA Synthesis | `camena-bioscience-gsynth` | 2021 | private | patented | ✓ |
| Cancer-immunotherapy organ-on-chip (2023-2026 academic) | `zhang-2023-organ-on-chip-cancer-immunotherapy` | 2023 | academic | patented |  |
| Canon imagePROGRAF GP Series with Fluorescent Pink Printhead | `canon-imageprograf-gp-series-fluorescent-pink-printhead` | 2022 | private | patented |  |
| Canon imagePROGRAF TX-3000/TX-4000 Wide-Format Aqueous Printhead | `canon-imageprograf-tx-3000-4000-aqueous-printhead` | 2017 | private | patented |  |
| Canon Oce ProStream 1800 Continuous-Feed Inkjet Press | `canon-oce-prostream-1800-continuous-feed-inkjet` | 2017 | private | patented |  |
| Canon Oce VarioPrint i-Series Cut-Sheet Inkjet Press | `canon-oce-varioprint-i-series-cut-sheet-inkjet` | 2015 | private | patented |  |
| Canon thermal Bubble Jet inkjet printhead | `canon-bubble-jet-printhead` | 1979 | private | patented |  |
| Capillary electrophoresis on a microchip | `harrison-1992-cap-electrophoresis-on-chip` | 1992 | academic | public-domain |  |
| Carbon Digital Light Synthesis (DLS / CLIP) Resin 3D Printer | `carbon-dls-clip-resin-printer` | 2015 | private | patented |  |
| Caribou Biosciences CB-010/CB-011 chRDNA Manufacturing | `caribou-biosciences-cb-001-mfg` | 2020 | private | patented |  |
| Cassini Cosmic Dust Analyzer (CDA) — Enceladus Plume Mass Spectra | `cassini-cda-cosmic-dust-analyzer` | 2004 | academic | public-domain |  |
| Catalog Technologies Shannon DNA Storage Platform | `catalog-technologies-shannon-dna-storage` | 2019 | private | patented |  |
| Catalog Technologies Shannon DNA Storage Write/Read System | `catalog-technologies-dna-storage` | 2019 | private | patented |  |
| Cellares Cell Shuttle CAR-T manufacturing platform | `cellares-cell-shuttle` | 2022 | private | patented |  |
| Cellbricks BioCarrier Bioprinter Platform | `cellbricks-biocarrier-bioprinter` | 2018 | private | patented |  |
| Cellenion cellenONE X1 (formerly F1.4) | `cellenion-cellenone-x1-single-cell-printer` | 2017 | private | patented |  |
| Cellink 3D bioprinters (BIO X / INKREDIBLE) | `cellink-bioprinter` | 2016 | private | patented |  |
| CELLINK BIO X Pneumatic Bioprinthead | `cellink-bio-x-pneumatic-printhead` | 2016 | private | patented |  |
| CELLINK BIONOVA Digital Light Processing Bioprinter | `cellink-bionova-stereolithography-bioprinter` | 2020 | private | patented |  |
| Cellipont Bioservices cell therapy CDMO platform | `cellipont-bioservices-cdmo` | 2022 | private | trade-secret | ✓ |
| Cellix Vena8 Biochip with Magnetofluidic Bead Capture | `cellix-vena8-magnetofluidics-chip` | 2009 | private | patented |  |
| CellSearch CTC isolation system | `kapur-2013-cellsearch-ctc-system` | 2003 | academic | patented |  |
| Cepheid GeneXpert cartridge | `cepheid-genexpert-cartridge` | 2004 | private | patented |  |
| Cepheid Xpress (rapid GeneXpert) cartridge | `cepheid-xpress-cartridge` | 2017 | private | patented |  |
| Chaotic mixer for microchannels (staggered herringbone) | `stroock-2002-staggered-herringbone-mixer` | 2002 | academic | public-domain |  |
| Charles River Laboratories Cobra Plasmid Manufacturing Platform | `charles-river-cobra-plasmid` | 2010 | private | patented |  |
| Charles Stross Glasshouse cornucopia matter compiler | `stross-glasshouse-cornucopia` | 2005 | fictional | fictional |  |
| Charles Stross Rule 34 pharma printer / domestic compounder | `stross-rule-34-pharma-printer` | 2011 | fictional | fictional |  |
| Charm II Test System (Receptor-based Drug Residue) | `charm-ii-radioimmuno-receptor-residue` | 1985 | private | patented |  |
| Charm Sciences PALCAM Listeria Rapid Test | `charm-palcam-listeria-rapid` | 2005 | private | patented |  |
| Charm Sciences PasLite/AP Pasteurization Phosphatase Test | `charm-pasteurization-phosphatase-test` | 1997 | private | patented |  |
| Charm Sciences ROSA Lateral Flow Reader | `charm-rosa-lateral-flow-reader` | 1998 | private | patented |  |
| ChemBio Diagnostics DPP (Dual Path Platform) lateral-flow | `chembio-dpp` | 2009 | private | patented |  |
| ChemoMetec NucleoCounter NC-200 / NC-3000 Single-Use Cassette | `chemometec-nucleocounter-nc-200-cassette` | 2008 | private | patented |  |
| Chemometec NucleoCounter NC-202 Cassette | `chemometec-nucleocounter-nc-202` | 2019 | private | patented |  |
| ChemoMetec NucleoCounter NC-3000 (Image Cytometer) | `chemometec-nucleocounter-nc-3000` | 2010 | private | patented |  |
| Chemtrix Labtrix S1 | `chemtrix-labtrix-s1` | 2009 | private | patented |  |
| Chemtrix Plantrix MR-series silicon-carbide microreactor | `chemtrix-plantrix-mr-series` | 2012 | private | patented |  |
| Chi.Bio open-hardware bioreactor | `chibio-bioreactor` | 2018 | open | open-permissive |  |
| Chiou & Wu Optoelectronic Tweezer (OET) Foundation | `chiou-wu-2005-optoelectronic-tweezer-foundation` | 2005 | academic | patented |  |
| Cixin Liu Ball Lightning experimental fluidics apparatus | `cixin-liu-ball-lightning-fluidics` | 2004 | fictional | fictional |  |
| Clearblue Connected Digital Pregnancy Test (Bluetooth) | `clearblue-connected-digital-pregnancy` | 2021 | private | patented |  |
| CleWin / KLayout microfluidic mask layout tools | `microfluidic-cad-software-clewinwin-cleWin` | 2003 | open | open-permissive |  |
| CLIP: continuous liquid interface production | `tumbleston-2015-clip-3d-printing` | 2015 | academic | patented |  |
| CNSA Tianwen-1 Zhurong Rover Fluidic Instruments | `tianwen1-zhurong-rover-instruments` | 2021 | private | unknown |  |
| CODEX multiplexed antibody imaging (Akoya CODEX/PhenoCycler) | `goldman-2014-codex-akoya` | 2014 | academic | patented |  |
| ColdQuanta MIQRO Cold-Atom MEMS Quantum Sensor Module | `coldquanta-miqro` | 2019 | private | patented |  |
| Color Health Genomics Sample Collection Kit | `color-health-genomics-cartridge` | 2015 | private | trade-secret | ✓ |
| Color-changing diagnostic paper microfluidics (multiple groups) | `psaltis-2014-color-changing-paper-microfluidic` | 2010 | academic | public-domain |  |
| CompactGTL Microchannel Gas-to-Liquids Reactor | `compactgtl-microchannel-reactor` | 2008 | private | patented |  |
| Computed axial lithography (CAL): volumetric 3D printing | `kelly-2019-cal-volumetric-printing` | 2019 | academic | patented |  |
| Continuous flow chemistry review (Ley 2013) | `ley-2013-flow-chemistry-pharma-review` | 2013 | academic | public-domain |  |
| Continuous high-throughput single-cell western blotting (scWestern) | `kim-2017-multilayer-soft-lithography-mems` | 2014 | academic | patented |  |
| Continuous inertial focusing, ordering, and separation of particles in microchannels | `di-carlo-2007-inertial-microfluidics` | 2007 | academic | patented |  |
| Continuous inkjet (Sweet 1965) | `sweet-1965-continuous-inkjet` | 1965 | academic | public-domain |  |
| Continuous-flow PCR on chip (Kopp 1998) | `quake-1997-pcr-on-chip` | 1998 | academic | patented |  |
| Continuous-flow pharmaceutical manufacturing on chip (Jensen 2016 MIT spinout-driven) | `adamo-2016-continuous-pharma-mit` | 2016 | academic | patented |  |
| Continuus Pharmaceuticals iCMM (Integrated Continuous Manufacturing Module) | `continuus-pharmaceuticals-icmm` | 2017 | private | patented |  |
| Continuus Pharmaceuticals Integrated Continuous Manufacturing (ICM) platform | `continuus-pharmaceuticals-icm` | 2012 | private | patented |  |
| Control (Remedy) Service Weapons fluidic-Hiss containment | `control-game-service-weapons` | 2019 | fictional | fictional | ✓ |
| Cordwainer Smith Norstrilia Stroon longevity treatment | `cordwainer-smith-stroon-treatment` | 1964 | fictional | fictional |  |
| Coriolis: The Third Horizon ship medbay modules | `coriolis-third-horizon-medbay` | 2017 | fictional | fictional | ✓ |
| Corning Advanced-Flow Reactor G1 | `corning-advanced-flow-reactor-g1` | 2007 | private | patented |  |
| Corning Advanced-Flow Reactor G3 (production-scale) | `corning-advanced-flow-reactor-g3` | 2010 | private | patented |  |
| Corning Advanced-Flow Reactor G4 (silicon-carbide) | `corning-advanced-flow-reactor-g4-sic` | 2014 | private | patented |  |
| Corning ULC-G2 ultra-low-cost flow reactor | `corning-ulc-g2-low-cost-flow-reactor` | 2018 | private | patented |  |
| Cory Doctorow Walkaway open-hardware autodoc | `doctorow-walkaway-open-autodoc` | 2017 | fictional | fictional |  |
| Counter Culture Labs community biology lab Oakland | `counter-culture-labs` | 2013 | open | open-permissive |  |
| Covaris ME220 / E220 focused-ultrasonic DNA shearing | `covaris-me220-acoustic-shearing` | 2002 | private | patented |  |
| Creating, transporting, cutting, and merging liquid droplets by electrowetting-based actuation | `cho-2003-creating-transporting-cutting-merging` | 2003 | academic | patented |  |
| CRISPR-Cas9 mechanism (Jinek 2012; Cong/Mali 2013) — context for CRISPR diagnostics | `zhang-jin-2011-cas9-discovery` | 2012 | academic | patented |  |
| CTC-iChip: inertial focusing for high-throughput rare-cell isolation | `ozkumur-2013-ctc-iChip` | 2013 | academic | patented |  |
| Cue Health Monitoring System cartridge | `cue-health-cartridge` | 2014 | private | patented |  |
| Curio Bioscience Curio Seeker (Slide-seq commercial) | `curio-bio-seeker-slideseq` | 2022 | private | patented |  |
| Curio Trekker spatial cell-tracking platform | `curio-trekker-spatial-celltracking` | 2024 | private | unknown | ✓ |
| Custom 3D printer and resin for 18×20 µm microfluidic flow channels | `gong-2017-3d-printed-18x20-microfluidic-channels` | 2017 | academic | public-domain |  |
| Cyberpunk 2020 / Cyberpunk RED Trauma Team field response | `cyberpunk-red-trauma-team` | 1990 | fictional | fictional |  |
| Cyberpunk 2020 Ripperdoc clinic published mechanics (extends wave 1) | `cyberpunk-2020-ripperdoc-extended` | 1990 | fictional | fictional |  |
| Cyberpunk 2077 braindance (BD) recording / playback fluidic rig | `cyberpunk-2077-bd-recording-rig` | 2020 | fictional | fictional |  |
| Cyberpunk 2077 ripperdoc chair / cyberware diagnostic suite | `cyberpunk-2077-ripperdoc-chair` | 2020 | fictional | fictional |  |
| Cyberpunk Edgerunners ripperdoc body-mod fluid handling | `cyberpunk-edgerunners-ripperdoc` | 2022 | fictional | fictional |  |
| Cyberpunk RED MaxTac response unit medical capability | `cyberpunk-red-maxtac-response` | 2020 | fictional | fictional | ✓ |
| Cyfuse Biomedical Regenova Kenzan-method bioprinter | `cyfuse-regenova` | 2010 | private | patented |  |
| Cygnus GlucoWatch G2 Biographer | `cygnus-glucowatch-biographer` | 1999 | private | patented |  |
| Cytek Aurora Spectral Flow Cytometer | `cytek-aurora-spectral-flow-cytometer` | 2017 | private | patented |  |
| Cytena C.SIGHT and B.SIGHT single-cell printers | `cytena-csight-bsight` | 2014 | private | patented |  |
| Cytiva FlexFactory for Cell Therapy | `cytiva-flexfactory-cell-therapy` | 2014 | private | patented |  |
| Cytiva Mobius MyWay Single-Use Mixer / MIX10 / MIX100 / MIX1000 / MIX2000 | `cytiva-mobius-myway` | 2010 | private | patented |  |
| Cytiva NanoAssemblr Spark / Benchtop / Ignite LNP Microfluidic Mixer Family | `cytiva-nanoassemblr-spark-benchtop-ignite` | 2018 | private | patented |  |
| Cytiva ReadyMate Sterile Connector | `cytiva-readymate-sterile-connector` | 2009 | private | patented |  |
| Cytiva Sefia S-2000 cell processing system | `cytiva-sefia` | 2015 | private | patented |  |
| Cytiva Xcellerex XDR single-use stirred-tank bioreactor | `cytiva-xcellerex-xdr` | 2007 | private | patented |  |
| Cytiva Xuri W25 / Wave 25 single-use rocking bioreactor | `cytiva-xuri-wave-bioreactor` | 1999 | private | patented |  |
| Cytiva ÄKTA ready single-use chromatography skid | `cytiva-akta-ready` | 2009 | private | patented |  |
| DAFD 3.0 — Double-Emulsion Droplet Design Automation | `lashkaripour-2024-dafd-double-emulsion` | 2024 | open | open-permissive |  |
| DAFD — Design Automation of Flow-Focusing Droplet Generators | `lashkaripour-2021-dafd-droplet-design-automation` | 2021 | open | open-permissive |  |
| Dako Omnis IHC / ISH stainer | `dako-omnis-stainer` | 2013 | private | patented |  |
| DARPA ICECool Embedded Two-Phase Cooling for High-Power Microelectronics | `darpa-icecool` | 2012 | academic | open-permissive |  |
| DARPA RAM Replay Memory-Restoration Neural Implant | `darpa-ram-replay-memory-implant` | 2018 | academic | patented |  |
| Darwin Microfluidics tubing and components shop | `darwin-microfluidics-shop` | 2016 | open | open-permissive |  |
| David Brin Streaker dolphin-crew medical bay (Startide Rising) | `brin-startide-rising-medbay` | 1983 | fictional | fictional |  |
| DBiT-seq spatial multi-omics on chip | `liu-fan-2020-dbit-seq` | 2020 | academic | patented |  |
| DC Cadmus Project cloning and genetic-engineering facility | `dc-cadmus-project-cloning` | 1971 | fictional | fictional |  |
| DC Lazarus Pit (Ra's al Ghul resurrection) | `dc-lazarus-pit` | 1971 | fictional | fictional |  |
| Dead Space RIG suit integrated medical injection | `dead-space-rig-medical-injection` | 2008 | fictional | fictional |  |
| Death Stranding Bridge Baby (BB) pod and chiral-fluid life support | `death-stranding-bb-pod` | 2019 | fictional | fictional |  |
| Death Stranding bridge baby fluid systems | `death-stranding-medbay` | 2019 | fictional | fictional |  |
| Deep learning for microfluidic imaging diagnostics (Ballard/Ozcan 2020) | `ballard-ozcan-2020-machine-learning-imaging` | 2020 | academic | patented |  |
| Desktop Metal Production System Single Pass Jetting | `desktop-metal-single-pass-jetting-production-system` | 2017 | private | patented |  |
| Detect Inc. COVID-19 RT-LAMP Cartridge | `detect-inc-covid-19-rt-lamp-cartridge` | 2021 | private | patented |  |
| DETECTR CRISPR-Cas12a nucleic acid detection | `chen-doudna-2018-detectr` | 2018 | academic | patented |  |
| Deterministic lateral displacement particle separation | `huang-2004-dld-deterministic-lateral-displacement` | 2004 | academic | patented |  |
| Detroit: Become Human android Thirium fluidics | `detroit-become-human-thirium` | 2018 | fictional | fictional |  |
| Developing optofluidic technology through the fusion of microfluidics and optics | `psaltis-2006-optofluidic-review` | 2006 | academic | public-domain |  |
| Devs (FX) quantum-computing vacuum / fluidic substrate chamber | `devs-quantum-vacuum-chamber` | 2020 | fictional | fictional |  |
| Dexcom G5 Mobile Continuous Glucose Monitor | `dexcom-g5-cgm` | 2015 | private | patented |  |
| Dexcom G6 Continuous Glucose Monitor | `dexcom-g6-cgm` | 2018 | private | patented |  |
| Dexcom G7 continuous glucose monitor sensor | `dexcom-g7-cgm` | 2022 | private | patented |  |
| Dexcom Stelo Glucose Biosensor System | `dexcom-stelo-otc-cgm` | 2024 | private | patented |  |
| Diagenode IP-Star Compact Automated Magnetic-Bead System | `diagenode-ipstar-magnetic-bead-automation` | 2010 | private | patented |  |
| Diagenode Megaruptor hydrodynamic DNA shearer | `diagenode-megaruptor` | 2013 | private | patented |  |
| Diagenode Megaruptor Mechanical DNA Shearing | `diagenode-megaruptor-bead-shear` | 2014 | private | patented |  |
| DiaSorin LIAISON XL Immunoassay Magnetic Bead Cuvette | `diasorin-liaison-xl-magnetic-bead-cuvette` | 2010 | private | patented |  |
| Diaspora polis physiological substrate | `diaspora-polis-physiology` | 1997 | fictional | fictional |  |
| Dielectrophoresis-based separation of human cancer cells from blood | `gascoyne-2002-dep-cancer-cells` | 2002 | academic | patented |  |
| Digital PCR | `vogelstein-kinzler-1999-digital-pcr` | 1999 | academic | patented |  |
| DISH: digital incoherent synthesis of holographic light fields | `wang-2026-dish-volumetric-3d-printing` | 2026 | academic | public-domain |  |
| DIYbio NYC | `diybio-nyc-genspace-affiliate` | 2008 | open | open-permissive |  |
| DIYNAFLUOR — $40 Open-Source 3D-Printed DNA Fluorometer | `diynafluor-low-cost-dna-fluorometer` | 2023 | open | open-permissive |  |
| DNA Script SYNTAX Enzymatic DNA Synthesis Storage Extension | `dna-script-storage-extension` | 2021 | private | patented |  |
| DNA Script SYNTAX Enzymatic DNA Synthesizer | `dna-script-syntax-enzymatic-synthesis` | 2020 | private | patented |  |
| DnaNudge / NudgeBox Rapid Cartridge PCR System | `dnanudge-rapid-cartridge` | 2020 | private | patented |  |
| DocuBricks open-hardware documentation platform | `docubricks-platform` | 2016 | open | open-permissive |  |
| Dolomite Microfluidics droplet generation system | `dolomite-microfluidics-droplet-system` | 2009 | private | patented |  |
| Domino A-Series A300 Continuous Inkjet Coder | `domino-a300-cij-coder` | 2014 | private | patented |  |
| Domino A-Series A400 Continuous Inkjet Coder | `domino-a400-cij-coder` | 2014 | private | patented |  |
| Domino Amjet (Domino Printing Sciences) Continuous Inkjet Coding Printer | `domino-amjet-cij-1978-coding-printer` | 1978 | private | patented |  |
| Domino V-Series Thermal Transfer Overprinter | `domino-v-series-thermal-transfer-overprinter` | 2010 | private | patented |  |
| Doom medkit autonomous trauma stim | `doom-medkit` | 1993 | fictional | fictional |  |
| Dragonfly Mass Spectrometer (DraMS) for Titan | `dragonfly-drams-titan-mass-spec` | 2022 | academic | public-domain |  |
| Drew Scientific HemaVet 950 / 1500 Veterinary Hematology Analyzer | `drew-scientific-hemavet-veterinary-cbc` | 1996 | private | patented | ✓ |
| Drop-seq single-cell RNA sequencing | `macosko-2015-drop-seq` | 2015 | academic | public-domain |  |
| DropBot open-source digital microfluidics platform | `dropbot-open-source-dmf` | 2013 | open | open-permissive |  |
| Droplet microfluidic technology for single-cell high-throughput screening | `brouzes-2009-droplet-screening` | 2009 | academic | patented |  |
| Droplet-based microfluidics review (Seemann 2012) | `seemann-2012-droplet-review` | 2012 | academic | public-domain |  |
| DStat — Open-Source Potentiostat for Electroanalysis and Integration | `dryden-2015-dstat-open-potentiostat` | 2015 | open | open-permissive |  |
| Duke SAW Single-Cell Acoustic Printer | `wang-duke-2019-saw-single-cell-printer` | 2019 | academic | patented |  |
| Dune axlotl tank — Tleilaxu ghola biological matter compiler | `dune-axlotl-tank-ghola` | 1976 | fictional | fictional |  |
| Dune Bene Gesserit poison-snooper / chemical microsensor | `dune-bene-gesserit-poison-snooper` | 1965 | fictional | fictional |  |
| Dune Part Two stillsuit body-fluid recycling (2024) | `dune-2-stillsuit-fluid-recycling` | 2024 | fictional | fictional |  |
| Dune Sardaukar / Bashar conditioning chambers | `dune-sardaukar-conditioning-chambers` | 1965 | fictional | fictional | ✓ |
| Dune Spacing Guild Navigator melange-saturated tank | `dune-spacing-guild-navigator-tank` | 1965 | fictional | fictional |  |
| Dune stillsuit body-fluid reclamation (Frank Herbert original 1965) | `dune-stillsuit-1965-original` | 1965 | fictional | fictional |  |
| Dune Tleilaxu vat-grown organs and replacement-tissue industry | `dune-tleilaxu-vat-grown-organs` | 1969 | fictional | fictional |  |
| Durst Rho with Quadro Array Printheads | `durst-quadro-array-rho-printer` | 2008 | private | patented | ✓ |
| Dynamic pattern formation in a vesicle-generating microfluidic device | `thorsen-2002-droplet-microfluidics-flow-focusing` | 2001 | academic | public-domain |  |
| Eccrine Systems Continuous Sweat Sensor Platform | `eccrine-systems-sweat-platform` | 2014 | private | patented |  |
| Echo 650 high-throughput acoustic dispenser (Labcyte/Beckman) | `echo-650-acoustic-dispenser-2009` | 2009 | private | patented |  |
| Echo acoustic droplet ejection (Labcyte) | `echo-acoustic-dispenser` | 2003 | academic | patented |  |
| Eckert & Ziegler ModularLab MX PET Tracer Synthesizer | `eckert-ziegler-modularlab` | 2009 | private | patented |  |
| Eclipse Phase healing vat / autodoc | `eclipse-phase-healing-vat` | 2009 | fictional | fictional |  |
| Eclipse Phase healing vat — detailed mechanics (extends wave 1) | `eclipse-phase-healing-vat-detailed` | 2009 | fictional | fictional |  |
| Eclipse Phase synthmorph internal fluid-skeleton and lubricant systems | `eclipse-phase-synthmorph-fluid-skeleton` | 2009 | fictional | fictional |  |
| Educational microfluidic kits for K-12 and undergraduate teaching | `open-microfluidic-edge-edu-kits` | 2018 | open | open-permissive |  |
| EFI VUTEk UltraDrop UV Wide-Format Inkjet Press | `efi-vutek-ultradrop-uv-wide-format` | 2001 | private | patented | ✓ |
| Ehrfeld Mikrotechnik BTS CYTOS College and Caterpillar microreactors | `ehrfeld-cytos-college-caterpillar` | 2002 | private | patented |  |
| Electroosmotic injection / pumping on chip CE | `harrison-1993-electroosmotic-cycling` | 1993 | academic | public-domain |  |
| Electrospray ionization from a microchip CE column | `ramsey-1996-electrospray-on-chip` | 1996 | academic | patented |  |
| Electrowetting-based actuation of liquid droplets for microfluidic applications | `pollack-2000-electrowetting-droplet` | 2000 | academic | patented |  |
| Element Biosciences AVITI Cloudbreak (Long-Read) | `element-biosciences-aviti-cloudbreak` | 2024 | private | patented |  |
| Element Biosciences AVITI sequencer flow cell | `element-biosciences-aviti` | 2022 | private | patented |  |
| ELSAH (Enceladus Life Signatures and Habitability) Mission Concept | `elsah-enceladus-life-signatures-habitability-concept` | 2018 | academic | unknown | ✓ |
| Elveflow OB1 pressure controller | `elveflow-ob1-pressure-controller` | 2014 | private | trade-secret |  |
| Elysium Cure-All medbay (Med-Bay) | `elysium-cure-all-medbay` | 2013 | fictional | fictional |  |
| Embark Veterinary Dog DNA Test Kit | `embark-veterinary-genetic-test-kit` | 2016 | private | patented |  |
| Emulate Inc. Organ-Chip platform | `emulate-organ-on-chip-platform` | 2014 | private | patented |  |
| Endo / Saito 1977 Canon Bubble Jet Priority Disclosure | `endo-saito-1977-canon-bubble-jet-priority` | 1977 | private | patented |  |
| Endress+Hauser Liquiline System CA80 Analyzer | `endress-hauser-liquiline-ca80-wet-chem` | 2015 | private | patented |  |
| Endress+Hauser Memosens Digital Sensor Platform | `endress-hauser-memosens-digital-probe` | 2004 | private | patented |  |
| Endress+Hauser SpectraTec In-Line Spectrometer Series | `endress-hauser-spectratec-spectrometer` | 2017 | private | patented | ✓ |
| Engineered Conductive Materials (ECM) Inkjet Silver Conductive Inks | `engineered-conductive-materials-inkjet-silver` | 2008 | private | patented | ✓ |
| Engineering flows in small devices: microfluidics toward a lab-on-a-chip | `stone-2004-engineering-flows-microfluidics` | 2004 | academic | public-domain |  |
| Engineering multi-organ microphysiological systems (multi-organ-on-chip) | `wikswo-2013-multi-organ-chip` | 2013 | academic | patented |  |
| Environmental microbiome sample-to-sequencing cartridges (2024 academic) | `environmental-microbiome-cartridge-2024` | 2024 | academic | patented |  |
| EnvisionTEC / ETEC 3D-Bioplotter | `envisiontec-3d-bioplotter` | 2002 | private | patented |  |
| EOFlow EOPatch Insulin Pump | `eoflow-eopatch-insulin` | 2017 | private | patented |  |
| Epicore Biosystems Microfluidic Sweat Sensor Patch | `epicore-biosystems-sweat-patch` | 2016 | private | patented |  |
| Eppendorf BioBLU 0.3c / 1.4f Single-Use Bioreactor | `eppendorf-bioblu-single-use-bioreactor` | 2013 | private | patented |  |
| Eppendorf BioBLU Single-Use Bioreactor (0.3c / 3c / 10c / 50c) | `eppendorf-bioblu-single-use` | 2012 | private | patented |  |
| Eppendorf BioFlo 320 / 720 Bioreactor Controller | `eppendorf-bioflo-320-720-bioreactor` | 2014 | private | patented |  |
| Eppendorf DASGIP Parallel Bioreactor System | `eppendorf-dasgip-parallel-bioreactor` | 2009 | private | patented |  |
| Eppendorf epMotion 5075 NGS Solution | `eppendorf-epmotion-5075-ngs` | 2017 | private | patented |  |
| Eppendorf epMotion automated pipetting system | `eppendorf-epmotion` | 2003 | private | patented |  |
| Epson MicroPiezo printhead (piezoelectric drop-on-demand) | `epson-microPiezo-printhead` | 1993 | private | patented |  |
| Epson PrecisionCore MicroTFP Print Chip | `epson-precisioncore-microtfp-chip` | 2013 | private | patented |  |
| Ergo Proxy Romdo dome citizen-management medical infrastructure | `ergo-proxy-dome-medical` | 2006 | fictional | fictional |  |
| Erickson Cornell Nanofluidic Optofluidic Platform | `erickson-cornell-2008-nanofluidic-optofluidic` | 2008 | academic | open-permissive |  |
| Europa Clipper SUrface Dust mass Analyzer (SUDA) | `europa-clipper-suda-particle-analyzer` | 2024 | academic | public-domain |  |
| Everlywell At-Home Sample Collection Kit | `everlywell-home-collection-kit` | 2015 | private | trade-secret | ✓ |
| eVOLVER multi-bioreactor evolution platform | `evolver-klavins` | 2018 | open | open-permissive |  |
| eVOLVER Open Multiplexed Continuous-Culture Bioreactor | `wong-2018-evolver-multiplex-bioreactor` | 2018 | open | open-permissive |  |
| Exact Sciences Cologuard Sample Stabilization Container | `exact-sciences-cologuard-prep` | 2014 | private | patented |  |
| ExoMars Rosalind Franklin MOMA (Mars Organic Molecule Analyser) | `exomars-moma-pyr-gcms-ldms` | 2017 | academic | public-domain |  |
| ExoMars TGO ACS (Atmospheric Chemistry Suite) | `exomars-tgo-acs-atmospheric-chemistry-suite` | 2015 | private | unknown |  |
| ExoMars TGO NOMAD (Nadir and Occultation for Mars Discovery) Gas Cell | `exomars-tgo-nomad-gas-flow-cell` | 2015 | private | unknown |  |
| ExOne X1-Series Industrial Metal Binder-Jet System | `exone-binder-jet-x1-25pro` | 2005 | private | patented |  |
| Exxon Office Systems Qwip Hot-Melt Inkjet (historical) | `exxon-office-systems-hot-melt-inkjet-historical` | 1980 | private | patented | ✓ |
| F-35 Lightning II AESA + Avionics Microchannel Liquid Cooling | `f-35-microchannel-cooling` | 2006 | private | patented |  |
| FabRx M3DIMAKER Pharmaceutical 3D Printer | `fabrx-m3dimaker-pharmaceutical-printer` | 2020 | private | patented |  |
| Fallout (Amazon) Vault medbay depictions (2024) | `fallout-tv-vault-medbay-2024` | 2024 | fictional | fictional |  |
| Fallout series Stimpak autoinjector | `fallout-stimpak-autoinjector` | 1997 | fictional | fictional |  |
| Features of gold by µCP using PDMS stamps | `kumar-whitesides-1993-microcontact-printing` | 1993 | academic | patented |  |
| Fette Compacting FE 35 / FE 75 Rotary Tablet Press | `fette-fe-rotary-tablet-press` | 2012 | private | patented |  |
| Field-deployable agricultural pathogen detection cartridges (Cady 2003 lineage) | `cady-2003-agricultural-pathogen-cartridge` | 2005 | academic | patented |  |
| Firefly Inara's Companion training-house medical suite | `firefly-inara-companion-medbay` | 2002 | fictional | fictional | ✓ |
| Firefly Niska's Skyplex interrogation/med table | `firefly-niska-skyplex-medtable` | 2002 | fictional | fictional | ✓ |
| Firefly River Tam Academy operating tables (neural intervention surgery) | `firefly-river-tam-academy-table` | 2005 | fictional | fictional |  |
| Firefly Simon Tam handheld medical kit | `firefly-simon-medical-bag` | 2002 | fictional | fictional |  |
| Flow-focusing droplet generation in microfluidic devices | `anna-2003-flow-focusing-droplet` | 2003 | academic | public-domain |  |
| Fluent BioSciences PIPseq particle-templated emulsification | `fluent-biosciences-pipseq` | 2022 | private | patented |  |
| FluidForm FRESH bioprinting platform | `fluidform-fresh-bioprinting` | 2015 | private | patented |  |
| Fluidic amplifier and pure-fluid digital logic | `goldstein-mueller-1968-fluidic-amplifier` | 1968 | academic | public-domain |  |
| Fluidic rectifier and microfluidic memory | `mosadegh-2010-fluidic-rectifier` | 2010 | academic | patented |  |
| Fluidigm C1 single-cell auto prep system | `fluidigm-c1-singlecell` | 2012 | private | patented |  |
| Fluidigm Dynamic Array Integrated Fluidic Circuit | `fluidigm-dynamic-array-ifc` | 2003 | private | patented |  |
| Fluidigm Helios mass cytometer (CyTOF re-registration with extended scope) | `fluidigm-helios-mass-cytometry` | 2015 | private | patented |  |
| Fluidigm/Standard BioTools CyTOF mass cytometer cartridge | `standard-biotools-mass-cytometry-cytof` | 2009 | private | patented |  |
| Fluigi — Microfluidic Device Synthesis CAD (Densmore lab) | `huang-densmore-2014-fluigi-microfluidic-cad` | 2014 | open | open-permissive |  |
| Fluxion BioFlux organ-on-chip platform | `fluxion-bioflux-platform` | 2009 | academic | patented |  |
| For All Mankind Jamestown lunar medbay | `for-all-mankind-jamestown-medbay` | 2019 | fictional | fictional |  |
| Formulatrix Mantis and Tempest nanoliter dispensers | `formulatrix-mantis-tempest` | 2013 | private | patented |  |
| Formulatrix Rock Imager / Mantis nanodispenser | `formulatrix-rock-imager-microreactor` | 2008 | private | patented |  |
| ForSight Vision5 Helios Bimatoprost Insert (Periocular Ring) | `forsight-vision5-helios-ring` | 2014 | private | patented | ✓ |
| Foundation (Apple TV) Genetic Dynasty cloning vat | `foundation-apple-tv-cloning-vat` | 2021 | fictional | fictional |  |
| Free-flow acoustophoresis for cell separation | `laurell-2007-acoustophoresis` | 2007 | academic | patented |  |
| FRESH: freeform reversible embedding of suspended hydrogels | `hinton-2015-fresh-printing` | 2015 | academic | patented |  |
| Friend & Yeo SAW Microfluidics Review | `friend-yeo-2011-saw-microfluidics-review` | 2011 | academic | open-permissive |  |
| FUJIFILM Dimatix Galaxy / Polaris / StarFire Industrial Piezo Heads (Spectra lineage) | `fujifilm-dimatix-galaxy-polaris-spectra-line` | 1996 | private | patented |  |
| FUJIFILM Dimatix Samba G3L Single-Pass MEMS Printhead | `fujifilm-dimatix-samba-g3l-printhead` | 2012 | private | patented |  |
| Fujifilm Dimatix Samba LFM Life-Sciences Printhead | `fujifilm-dimatix-samba-lfm-life-sciences-printhead` | 2016 | private | patented |  |
| Fujifilm DRI-CHEM Veterinary Slide System | `fujifilm-dri-chem-vet-slide` | 1981 | private | patented |  |
| Fulwyler electrostatic cell sorter (foundation of FACS) | `fulwyler-1965-cell-sorter-foundation` | 1965 | academic | public-domain |  |
| Future Chemistry FlowStart Evo and FlowSyn (FutureChem BV) | `future-chemistry-flowstart` | 2008 | private | patented |  |
| Future Chemistry FlowSyn ECs Electrochemistry Reactor | `future-chemistry-flowsyn-electrochemistry` | 2019 | private | patented | ✓ |
| Gatorade Gx Sweat Patch | `gatorade-gx-sweat-patch` | 2021 | private | patented |  |
| Gattaca instant genome / blood readout console | `gattaca-instant-genome-readout` | 1997 | fictional | fictional |  |
| GE Healthcare FASTlab FDG Synthesizer | `ge-fastlab-fdg` | 2008 | private | patented |  |
| GEA ConsiGma 1 Continuous Pilot Tableting Line | `gea-consigma-1-continuous-pilot-line` | 2014 | private | patented |  |
| GEA ConsiGma 25 Continuous Tableting Line | `gea-consigma-25-continuous-tableting` | 2010 | private | patented |  |
| Generation of gradients having complex shapes using microfluidic networks | `dertinger-2001-christmas-tree-gradient` | 2001 | academic | public-domain |  |
| Genia Technologies (Roche) nanopore sequencing | `genia-roche-nanopore` | 2009 | private | patented |  |
| GenMark ePlex cartridge | `genmark-eplex-cartridge` | 2014 | private | patented |  |
| Genspace NYC community biology lab | `genspace-community-lab` | 2010 | open | open-permissive |  |
| Ghost in the Shell cyberbrain immersion / maintenance fluidics | `ghost-in-the-shell-major-cyberbrain-fluidics` | 1989 | fictional | fictional |  |
| Ghost in the Shell cybernetic-body diagnostic facility | `ghost-in-the-shell-cybernetic-diagnostics` | 1995 | fictional | fictional |  |
| Gilead Lenacapavir Long-Acting Subcutaneous Depot (comparator) | `intarcia-medici-comparator-gilead-lenacapavir` | 2020 | private | patented | ✓ |
| Ginkgo Bioworks synthetic biology foundry (microfluidic-equivalent strain engineering) | `ginkgo-bioworks-foundry` | 2014 | private | trade-secret |  |
| Glass microchannel electrophoresis with ISFET detection (van den Berg group) | `van-den-berg-1998-glass-channel-electrophoresis` | 1998 | academic | patented |  |
| Glatt MODCOS / GMG-IIR Continuous Granulation System | `glatt-modcos-continuous-granulation` | 2014 | private | patented |  |
| Glia Project low-resource microfluidic devices (otoscope, etc.) | `glia-microfluidics-low-resource` | 2015 | open | open-permissive |  |
| GraphWear Non-Invasive Glucose Monitor | `graphwear-non-invasive-glucose` | 2017 | private | patented | ✓ |
| Greg Bear Blood Music intracellular fluidic agents | `bear-blood-music-nanofluidic-infection` | 1985 | fictional | fictional |  |
| Greg Egan gleisner robot fluidic body chemistry | `egan-diaspora-gleisner-fluidics` | 1997 | fictional | fictional |  |
| Greg Egan neural mod implant pharmaceutical synthesis | `egan-quarantine-mod-implants` | 1992 | fictional | fictional |  |
| Greg Egan Permutation City scanning / medical-substrate apparatus | `egan-permutation-city-medical` | 1994 | fictional | fictional |  |
| GSK / CMAC Strathclyde continuous-flow API manufacturing platform | `gsk-strathclyde-cmac-continuous-api` | 2011 | academic | patented |  |
| GURPS Bio-Tech sourcebook (Steve Jackson Games 1996) | `gurps-bio-tech-sourcebook` | 1996 | fictional | fictional |  |
| Gut-on-chip with peristalsis-mimicking mechanical strain | `kim-ingber-2012-gut-on-chip` | 2012 | academic | patented |  |
| Gyros Bioaffy CD immunoassay platform | `gyros-bioaffy-cd` | 2002 | private | patented |  |
| Hach BioTector B7000 / B3500 TOC Analyzer | `hach-biotector-b7000-toc-flow-cell` | 2000 | private | patented |  |
| Hackteria community microfluidics tutorials | `hackteria-microfluidics` | 2009 | open | open-permissive |  |
| Hackuarium community DIY-bio lab | `hackuarium-community-lab` | 2014 | open | open-permissive |  |
| Hackuarium — Citizen-Driven Open Bio Lab (Lausanne) | `hackuarium-living-instruments-2014` | 2014 | open | open-permissive |  |
| Haemonetics TEG 6s Thromboelastography Microfluidic Cartridge | `mindray-teg-6s-thromboelastography-cartridge` | 2014 | private | patented |  |
| Half-Life HEV suit morphine / analgesic injection | `half-life-hev-suit-injection` | 1998 | fictional | fictional |  |
| Halo CASTLE Base biological augmentation laboratories | `halo-castle-base-biolabs` | 2001 | fictional | fictional |  |
| Halo Forerunner Composer mass-state-conversion array (fluidic interpretation) | `halo-forerunner-composer-fluidic` | 2012 | fictional | fictional | ✓ |
| Halo medical bay automated diagnostics | `halo-cortana-medical` | 2001 | fictional | fictional |  |
| Halo MJOLNIR armor biofoam emergency wound-sealant injector | `halo-mjolnir-biofoam-injection` | 2001 | fictional | fictional |  |
| Halo MJOLNIR Smart-Link armor-to-medbay biotelemetry | `halo-smart-link-armor-medbay` | 2001 | fictional | fictional |  |
| Halo SPARTAN-II augmentation procedure (Project ORION-derived) | `halo-spartan-ii-augmentation-procedure` | 2001 | fictional | fictional |  |
| Halo SPARTAN-III SPI armor and CHAPS augmentation chemical regime | `halo-spartan-iii-spi-armor-injection` | 2003 | fictional | fictional |  |
| Halo UNSC Constantinople-class hospital ship | `halo-unsc-hospital-ship-constantinople` | 2009 | fictional | fictional |  |
| Halo: Reach Sword Base medical and recovery rooms | `halo-reach-hospital-scenes` | 2010 | fictional | fictional |  |
| Hamilton Arc Intelligent Sensors (pH, DO, ORP, conductivity) | `hamilton-arc-sensors` | 2010 | private | patented |  |
| Hamilton Microlab STAR liquid handler | `hamilton-microlab-star` | 2003 | private | patented |  |
| Hamilton Microlab Vantage NA Extraction Workstation | `hamilton-microlab-vantage-na-extraction` | 2017 | private | patented |  |
| Hannu Rajaniemi gevulot privacy-managed body chemistry | `rajaniemi-quantum-thief-gevulot-biology` | 2010 | fictional | fictional |  |
| Hayabusa-2 MASCOT Lander Sample-Handling Subsystem | `hayabusa2-mascot-lander-sample-handling` | 2017 | private | unknown |  |
| Heidelberg Primefire 106 B1 Sheetfed Inkjet Press | `heidelberg-primefire-106-b1-inkjet` | 2016 | private | patented |  |
| Heinzl / Hertz 1979 Lund Binary Continuous Jet System | `heinzl-hertz-1979-binary-continuous-jet-lund` | 1979 | academic | patented |  |
| HEL FlexFermentor Parallel Bioreactor System | `hel-flexfermentor-parallel-bioreactor` | 2012 | private | trade-secret | ✓ |
| HEL FlowCAT continuous catalysis flow reactor | `hel-flowcat-catalysis` | 2007 | private | patented |  |
| HEL Hexa Vessel Parallel Bioreactor System | `hel-hexa-vessel-parallel-bioreactor` | 2014 | private | patented |  |
| HemoCue Hb 201+ Capillary Hemoglobin Analyzer | `hemocue-201-capillary-eof-analyzer` | 1986 | private | patented |  |
| Hertz–Simonsson Continuous Inkjet (Lund Institute) | `hertz-simonsson-1965-lund-cij` | 1965 | academic | patented |  |
| Heska Element AIM (Automated Image Microscopy) | `heska-element-aim-image-cytometry` | 2019 | private | patented |  |
| Heska Element DC5X Chemistry Analyzer | `heska-element-dc5x-chemistry` | 2019 | private | patented |  |
| Heska Element HT5 Veterinary Hematology Image Cytometry Analyzer | `heska-element-ht5-veterinary-imaging` | 2018 | private | patented |  |
| Heska Element POC Blood Gas/Electrolyte Analyzer | `heska-element-poc-blood-gas` | 2017 | private | patented |  |
| Heska RAPID Reader (Allergy and Vector-Borne Lateral Flow) | `heska-rapid-reader-lateral-flow` | 2018 | private | patented |  |
| Heska veterinary POC cartridge platform | `heska-veterinary-cartridge` | 2010 | private | patented |  |
| High-performance heat sinking for VLSI (microchannel cooling) | `tuckerman-pease-1981-microchannel-cooling` | 1981 | academic | public-domain |  |
| High-speed separation of antisense oligonucleotides on a micromachined capillary electrophoresis device | `effenhauser-1993-glass-microchip-electrophoresis` | 1993 | academic | public-domain |  |
| Hitachi 7080/7180/7600 clinical chemistry analyzer | `hitachi-7080-clinical-chemistry` | 1995 | private | patented |  |
| Hitachi RX2 Continuous Inkjet Coder | `hitachi-rx2-cij-coder` | 2018 | private | patented |  |
| Hitachi UX-Series Continuous Inkjet Coder | `hitachi-ux-series-cij-coder` | 2014 | private | patented |  |
| Hitchhiker's Nutri-Matic Drinks Synthesizer | `hitchhikers-nutrimat-drink-machine` | 1979 | fictional | fictional |  |
| Hive BioLab — Open-Source Low-Cost Lab Equipment Suite (Ghana) | `akligoh-2020-hive-biolab-bioreactor` | 2020 | open | open-permissive | ✓ |
| HOLD (Habitability and Organic Life Detection) Microfluidic Payload Concept | `hold-habitability-organic-life-detection-concept` | 2019 | academic | unknown | ✓ |
| Hologic Panther / Panther Fusion Multiplex PCR Cartridge System | `hologic-panther-fusion-cartridge` | 2012 | private | patented |  |
| Holoxica 3D Drug Delivery Platform (Edinburgh) | `holoxica-3d-drug-delivery-edinburgh` | 2017 | private | unknown | ✓ |
| Honeycomb Biotechnologies HIVE scRNAseq solution | `honeycomb-hive-scrnaseq` | 2021 | private | patented |  |
| Honeywell HEMTOR (Hyperbolic Electrostatic Mass Trap with Orbital Resonance) | `honeywell-hemtor-flight-mass-spectrometer` | 2012 | private | patented | ✓ |
| Horizon Zero Dawn Cradle facility (genetic ark + Elisabet Sobeck reconstruction) | `horizon-zero-dawn-cradle` | 2017 | fictional | fictional |  |
| Howtek Pixelmaster Hot-Melt Inkjet Printer (historical) | `howtek-pixelmaster-hot-melt-inkjet-historical` | 1984 | private | patented |  |
| HP Multi Jet Fusion Thermal-Agent Inkjet Array | `hp-multi-jet-fusion-thermal-agent-array` | 2014 | private | patented |  |
| HP PageWide A50/A53 HDNA Pagewide Thermal Inkjet Array | `hp-pagewide-a50-a53-hdna-printhead-array` | 2012 | private | patented |  |
| HP ThinkJet thermal inkjet printhead | `hp-thinkjet-thermal-inkjet` | 1984 | private | patented |  |
| Hudson Robotics SOLO and PlateMate liquid-handling robots | `hudson-solo-platemate` | 1996 | private | unknown | ✓ |
| Hughes & Markx DEP Textbook (Nanoelectromechanics in Engineering and Biology) | `hughes-markx-2002-dep-textbook-foundation` | 1999 | academic | open-permissive |  |
| Huygens Aerosol Collector and Pyrolyser (ACP) | `cassini-huygens-acp-aerosol-collector-pyrolyser` | 2002 | private | unknown |  |
| Hygiena BAX System Real-Time PCR Pathogen Detection | `hygiena-bax-system-pathogen-pcr` | 1996 | private | patented |  |
| Hygiena EnSURE cleanliness ATP cartridge | `hygiena-eccelsis-cartridge` | 2004 | private | patented |  |
| Hygiena Innovate ATP Hygiene Monitoring System | `hygiena-innovate-atp-luminometer` | 2018 | private | patented |  |
| Hyperion Cantos cybrid / megasphere neural perfusion hookups | `hyperion-cantos-brain-hookups` | 1989 | fictional | fictional |  |
| Hyperion Cruciform parasitic implant (resurrection bioparasite) | `hyperion-cruciform-parasite` | 1989 | fictional | fictional |  |
| Hyperion Pax Mercantilus advanced medical / longevity service | `hyperion-pax-mercantilus-medical` | 1996 | fictional | fictional | ✓ |
| Hyperion Pax Reactivation Center medbay (Cruciform-mediated resurrection facility) | `hyperion-reactivation-center-medbay` | 1996 | fictional | fictional |  |
| i-STAT cartridge family (CHEM8+, CG8+, etc.) | `i-stat-cartridge-cg8plus` | 1992 | private | patented |  |
| Iain M. Banks Culture autodoc / medical bay | `banks-culture-autodoc` | 1987 | fictional | fictional |  |
| Iain M. Banks Culture endogenous drug glands | `banks-culture-drug-glands` | 1988 | fictional | fictional |  |
| IBA Synthera + Synthera Extension Radiosynthesizer | `iba-synthera` | 2008 | private | patented |  |
| IBIDI µ-Slide chemotaxis chamber | `ibidi-mu-slide-chemotaxis` | 2007 | private | patented |  |
| IDEXX Catalyst Dx Chemistry Analyzer | `idexx-catalyst-dx-multilayer-slide` | 2008 | private | patented |  |
| IDEXX Catalyst One Chemistry Analyzer (CLIP cartridge) | `idexx-catalyst-one-chemistry-cartridge` | 2013 | private | patented |  |
| IDEXX Colilert / Colilert-18 Reagent Snap-Pack | `idexx-colilert-reagent-snap-pack` | 1989 | private | patented |  |
| IDEXX Colilert water quality test (E. coli / coliform) | `idexx-colilert-water` | 1989 | private | patented |  |
| IDEXX LaserCyte Dx Hematology Analyzer | `idexx-lasercyte-dx-veterinary-hematology` | 2002 | private | patented |  |
| IDEXX ProCyte Dx Veterinary Hematology Analyzer Optical/Impedance Flow Cell | `idexx-procyte-dx-veterinary-hematology` | 2010 | private | patented |  |
| IDEXX ProCyte One Hematology Analyzer | `idexx-procyte-one-veterinary-hematology` | 2020 | private | patented |  |
| IDEXX Pseudalert and Enterolert Reagent Snap-Packs | `idexx-pseudalert-enterolert-water` | 1995 | private | patented |  |
| IDEXX Quanti-Tray and Quanti-Tray/2000 | `idexx-quanti-tray-mpn-water` | 1996 | private | patented |  |
| IDEXX Quanti-Tray Sealer | `idexx-quanti-tray-sealer-instrument` | 1996 | private | patented |  |
| IDEXX SediVue Dx Urine Sediment Analyzer | `idexx-sedivue-dx-urinalysis-ml` | 2015 | private | patented |  |
| IDEXX SNAP 4Dx Plus Test | `idexx-snap-4dx-plus-vector-borne` | 2012 | private | patented |  |
| IDEXX SNAP cPL (Canine Pancreatic Lipase) Test | `idexx-snap-cpl-canine-pancreatic-lipase` | 2008 | private | patented |  |
| IDEXX SNAP veterinary lateral-flow cartridge family | `idexx-snap-veterinary` | 1995 | private | patented |  |
| IDEXX VetLab Station | `idexx-vetlab-station-network-hub` | 2001 | private | patented |  |
| IDEXX VetStat Electrolyte and Blood Gas Analyzer | `idexx-vetstat-blood-gas-cassette` | 2001 | private | patented |  |
| IDEXX VetTest 8008 Chemistry Analyzer | `idexx-vettest-8008-dry-chemistry` | 1992 | private | patented |  |
| iGEM Cooper Union 2014 — Microfluidic DNA Synthesis Optimization Platform | `igem-cooper-union-2014-dna-synthesis-microfluidics` | 2014 | open | open-permissive |  |
| iGEM EPF Lausanne 2014 — BioPad Microfluidic Touch-Responsive Chip | `igem-epfl-2014-microfluidic-biopad` | 2014 | open | open-permissive |  |
| iGEM EPFL 2018 — CRISPR-Cas12a ctDNA Detection Microfluidic Chip | `igem-epfl-2018-crispr-ctdna-microfluidics` | 2018 | open | open-permissive |  |
| iGEM ETH Zurich 2018 — Microfluidic Chip Platform | `igem-eth-zurich-2018-microfluidic-chip` | 2018 | open | open-permissive |  |
| iGEM Foundation Distribution Kit | `igem-distribution-kit` | 2003 | open | open-permissive |  |
| iGEM HKUST 2020 — CRISPR-Cas13 Microfluidic RNA Detection Project | `igem-hkust-2020-crispr-cas13-detection` | 2020 | open | open-permissive | ✓ |
| iGEM Imperial College London 2014 — Aqualose Customisable Bacterial-Cellulose Ultrafiltration Membrane | `igem-imperial-2014-aqualose-membrane` | 2014 | open | open-permissive |  |
| iGEM Toronto 2019 — PETase Microfluidic Reactor for PET Hydrolysis | `igem-toronto-2019-petase-microfluidics` | 2019 | open | open-permissive | ✓ |
| iGEM TU Delft–Leiden 2014 — Paper Microfluidics for Electrace Biosensor | `igem-tu-delft-2014-paper-microfluidics` | 2014 | open | open-permissive |  |
| iGEM Wageningen UR 2019 — Insect Vector Pathogen Detection Device | `igem-wageningen-ur-2019-detection-device` | 2019 | open | open-permissive |  |
| IKA ElectraSyn 2.0 Electrochemistry Research Instrument | `ika-electrasyn-2-electrochemistry` | 2017 | private | patented |  |
| Illumina NeoPrep digital-microfluidic NGS library prep | `advanced-liquid-logic-illumina-neoprep` | 2014 | private | patented |  |
| Illumina Solexa sequencing flow cell | `bentley-2008-illumina-flow-cell` | 2008 | academic | patented |  |
| IMA Continuous Pre-Compactor | `ima-continuous-pre-compactor` | 2018 | private | patented | ✓ |
| Imaje S8 Master Continuous Inkjet Coder (historical) | `imaje-s8-master-cij-coder-historical` | 1992 | private | patented | ✓ |
| Imec Silicon Nitride Photonic Biosensor Platform | `imec-photonic-biosensor-lab-on-chip` | 2018 | private | patented |  |
| IMM Institut für Mikrotechnik Mainz modular microreactors (slit/interdigital/Caterpillar) | `imm-mainz-modular-microreactors` | 1997 | academic | patented |  |
| Inca Digital Onset / Onset X Flatbed Industrial UV Inkjet Press | `inca-onset-x-fujifilm-flatbed` | 2000 | private | patented |  |
| inDrops: droplet-based barcoding for single-cell transcriptomics | `klein-2015-indrops` | 2015 | academic | public-domain |  |
| Ineratec PtX microreactor for e-fuels and Power-to-Liquid | `ineratec-ptx-microreactor` | 2016 | private | patented |  |
| Infors HT Multitron Incubator Shaker (Cell / Pro) | `infors-multitron-cell-incubator-shaker` | 2000 | private | patented |  |
| Infors HT Multitron Pro Parallel Shake-Flask Incubator | `infors-multitron-pro-shaker-incubator` | 2012 | private | patented |  |
| Ingber lab organ-chip platform (Wyss Institute) | `ingber-emulate-organ-chip` | 2010 | academic | patented |  |
| Inpeco FlexLab Pre-Analytical Sample Transport Track | `inpeco-flexlab-preanalytical-track` | 2003 | private | patented |  |
| Inscopix nVista Head-Mounted Miniature Calcium-Imaging Microscope | `inscopix-nvista-miniscope` | 2011 | private | patented |  |
| Inscripta Onyx Digital Genome Engineering Platform | `inscripta-onyx-genome-engineering` | 2019 | private | patented |  |
| Institut Pasteur CRISPR cartridge work (academic) | `pasteur-crispr-cartridge-academic` | 2020 | academic | patented |  |
| Insulet OmniPod tubeless insulin pump | `insulet-omnipod-cartridge` | 2005 | private | patented |  |
| Intarcia ITCA 650 Implantable Osmotic Mini-Pump (Exenatide) | `intarcia-itca-650-osmotic-pump` | 2008 | private | patented |  |
| IntelliCyt iQue Screener Plus / Forecyt Software | `intellicyt-ique-screener-plus` | 2011 | private | patented |  |
| Inventia Life Science RASTRUM 3D cell-model printer | `inventia-rastrum` | 2019 | private | patented |  |
| IO Rodeo Rodeostat Open-Source Potentiostat | `iorodeo-rodeostat-open-potentiostat` | 2017 | open | open-copyleft |  |
| Ion Torrent semiconductor sequencing chip | `rothberg-2011-ion-torrent` | 2011 | academic | patented |  |
| IonSense DART (Direct Analysis in Real Time) Ion Source | `ionsense-dart` | 2005 | private | patented |  |
| Iontophoretic / reverse iontophoretic sampling on skin (Heikenfeld lineage) | `kim-rogers-iontophoresis-skin-2014` | 2014 | academic | patented |  |
| Iota Biosciences Ultrasonic Neural Dust Implant | `iota-biosciences-neural-dust` | 2016 | private | patented |  |
| Iridia DNA Data Storage Chip | `iridia-dna-storage-chip` | 2020 | private | patented | ✓ |
| Iris Graphics 3047 Drum Continuous Inkjet Proofer | `iris-graphics-3047-drum-cij` | 1985 | private | patented |  |
| Iron Man Bleeding Edge armor (subdermal nanofluidic suit storage) | `iron-man-bleeding-edge-armor` | 2010 | fictional | fictional |  |
| Iron Man Extremis virus injection and recovery | `iron-man-extremis-injection` | 2005 | fictional | fictional |  |
| Isaac Asimov Robots of Dawn positronic-brain assembly cell | `asimov-robots-of-dawn-positronic-cell` | 1983 | fictional | fictional |  |
| IsoPlexis IsoLight / IsoSpark Single-Cell Secretome Platform | `isoplexis-isolight-single-cell-secretome` | 2017 | private | patented |  |
| ISRO Aditya-L1 PAPA (Plasma Analyser Package for Aditya) | `isro-aditya-l1-papa-payload` | 2023 | private | unknown | ✓ |
| ISRO Chandrayaan-3 ChaSTE / Pragyan Rover Fluidic Instruments | `isro-chandrayaan3-chaste-pragyan-instrument` | 2023 | private | unknown |  |
| ISS Biomolecule Sequencer (Oxford Nanopore MinION on ISS) | `iss-biomolecule-sequencer-minion` | 2016 | open | patented |  |
| ISS Lab-on-Chip Application Development Portable Test System (LOCAD-PTS) | `iss-locad-pts-handheld-bioassay` | 2007 | academic | patented |  |
| ISS WetLab-2 Real-Time RT-PCR on Station | `iss-wetlab-2-rt-pcr-on-station` | 2016 | open | open-permissive |  |
| Jacobson & Ramsey Electroosmotic Pumping Foundation (1994-1996) | `ehd-electroosmotic-flow-foundation-jacobson` | 1994 | academic | patented |  |
| James S.A. Corey Expanse MCRN forge ship medical facility (extends wave 1) | `expanse-mcrn-forge-medical` | 2014 | fictional | fictional |  |
| Jana Care Aina Portable Diagnostic Device | `jana-care-aina-portable-device` | 2014 | private | patented |  |
| Janssen / Johnson & Johnson Prezista (darunavir) continuous manufacturing line | `janssen-tablet-press-cm-line` | 2016 | private | patented |  |
| Janssen ConTabLine Continuous Tableting Platform | `janssen-contabline-continuous-tableting-line` | 2018 | private | patented |  |
| Janssen Prezista Continuous Direct Compression Manufacturing Line | `janssen-prezista-continuous-direct-compression-line` | 2016 | private | patented |  |
| JAXA Hayabusa-1 Sample Return Capsule (Itokawa) | `jaxa-hayabusa-1-sample-return-capsule` | 2006 | private | unknown |  |
| JAXA Hayabusa-2 Sample Return Capsule (Ryugu) | `jaxa-hayabusa-2-sample-return-capsule` | 2018 | private | unknown |  |
| John Scalzi Old Man's War CDF Greenie body conversion (consciousness transfer to engineered body) | `scalzi-old-mans-war-cdf-greenie` | 2005 | fictional | fictional |  |
| JoVE (Journal of Visualized Experiments) microfluidics protocols | `jove-microfluidics-protocols` | 2006 | open | open-permissive |  |
| Jubilee Open-Source Multi-Tool Motion Platform | `vasquez-2022-jubilee-toolchanger-platform` | 2022 | open | open-permissive |  |
| Jules Verne Nautilus onboard surgical and medical facility (Twenty Thousand Leagues) | `verne-nautilus-onboard-surgery` | 1870 | fictional | fictional |  |
| Just One Giant Lab (JOGL) | `jogl-just-one-giant-lab` | 2018 | open | open-permissive |  |
| Karius Test cfDNA Microbial Prep | `karius-test-cfmdna-prep` | 2017 | private | patented |  |
| KEMRI Open Hardware Diagnostics Platform | `kemri-open-diagnostics-platform` | 2019 | open | open-permissive | ✓ |
| Kenzen ECHO H2 Smart Patch | `kenzen-echo-h2-sweat-patch` | 2017 | private | patented |  |
| KGK (Konishi Engineering) Jet Series Continuous Inkjet Coder | `kgk-jet-cij-coder` | 1995 | private | patented | ✓ |
| Kidney proximal tubule-on-chip | `jang-suh-2013-kidney-on-chip` | 2013 | academic | patented |  |
| Kim Stanley Robinson 2312 gene-mod treatment cells | `ksr-2312-gene-mod-cells` | 2012 | fictional | fictional |  |
| Kim Stanley Robinson Aurora generation-ship life-support cell handling | `ksr-aurora-life-support` | 2015 | fictional | fictional |  |
| Kim Stanley Robinson Mars trilogy longevity treatment process | `ksr-mars-trilogy-longevity-treatment` | 1993 | fictional | fictional |  |
| Klipper-Controlled Open-Source Syringe Pump | `klipper-syringe-pump-firmware-port` | 2022 | open | open-copyleft | ✓ |
| Knauer IJM (Impingement Jets Mixer) for mRNA-LNP Manufacturing | `knauer-impingement-jets-mrna` | 2021 | private | patented |  |
| Knights of Sidonia Gauna research / pilot regen tank | `knights-of-sidonia-gauna-medbay` | 2009 | fictional | fictional |  |
| Kobelco SUMC stacked-microchannel-reactor (Sumitomo platform) | `kobelco-sumc-stacked-microchannel-reactor` | 2005 | private | patented |  |
| Komori Impremia IS29 B2 Sheetfed Inkjet Press | `komori-impremia-is29-b2-sheetfed-inkjet` | 2014 | private | patented |  |
| Komori Impremia NS40 B1 Nanographic Sheetfed Inkjet Press | `komori-impremia-ns40-b1-sheetfed-inkjet` | 2018 | private | patented |  |
| Konica Minolta AccurioJet KM-1 B2 UV Inkjet Press | `konica-minolta-accuriojet-km1-b2-uv-inkjet-press` | 2015 | private | patented |  |
| Konica Minolta KM1024 Shared-Wall Shear-Mode Piezo Printhead | `konica-minolta-km1024-shared-wall-printhead` | 2008 | private | patented |  |
| Korsch XL 200 / XL 800 Rotary Tablet Press | `korsch-xl-rotary-tablet-press` | 2008 | private | patented |  |
| Krytox-PFPE surfactant for biocompatible droplet stabilization | `abate-2010-surfactant-survey` | 2008 | academic | patented |  |
| Kumasi Hive BioLab — Ghanaian Open Bio-Hardware Hub | `kumasi-hive-biolab-ghana` | 2019 | open | open-permissive |  |
| Kyocera KJ4 Series Bend-Mode Piezo Industrial Printhead | `kyocera-kj4-bend-mode-piezo-printhead` | 2014 | private | patented |  |
| Kyser & Sears 1972 Priority Bend-Mode Piezo Inkjet Disclosure | `kyser-sears-1972-priority-piezo-bend-mode` | 1972 | private | patented |  |
| L.B. Bohle KOMPRESS Continuous Tablet Press Module | `lb-bohle-kompress-continuous-tablet-press` | 2017 | private | patented |  |
| La Paillasse Paris community biology lab | `la-paillasse-community-lab` | 2011 | open | open-permissive |  |
| Lab-on-a-CD: centrifugal microfluidics platform | `madou-2006-centrifugal-microfluidics` | 2006 | academic | patented |  |
| Lab-on-a-chip: microfluidics in drug discovery | `dittrich-manz-2006-utas-review` | 2006 | academic | public-domain |  |
| LACE-NMR (Lab on a Chip Experiment Nuclear Magnetic Resonance) Mars Concept | `lace-nmr-mars-in-situ-nmr-concept` | 2014 | academic | unknown | ✓ |
| LAMA Cellpress laser-assisted bioprinter | `lama-cellpress-laser-bioprinter` | 2021 | private | patented |  |
| Landa S10 Nanographic Sheetfed Press | `landa-s10-nanographic-press` | 2018 | private | patented |  |
| Landa W10 Nanographic Web Press | `landa-w10-nanographic-web-press` | 2018 | private | patented |  |
| Larry Niven Known Space autodoc | `niven-known-space-autodoc` | 1970 | fictional | fictional |  |
| Latching microfluidic valves and digital logic | `weaver-2010-microfluidic-large-scale-integration` | 2010 | academic | patented |  |
| Lee Company / TTP Ventus Disc Pump | `lee-company-disc-pump-piezoelectric` | 2009 | private | patented |  |
| Lee fixed-volume solenoid dispense pump | `lee-fixed-volume-dispense-pump` | 2007 | private | patented |  |
| Leica Bond-III automated immunohistochemistry stainer | `leica-bond-iii-staining` | 2007 | private | patented |  |
| LetsGetChecked Home Test Collection Kit | `letsgetchecked-home-collection` | 2015 | private | trade-secret | ✓ |
| Lexmark Thermal Inkjet Heater Chip | `lexmark-thermal-inkjet-heater-chip` | 1996 | private | patented |  |
| Life at low Reynolds number | `purcell-1977-life-at-low-reynolds` | 1977 | academic | public-domain |  |
| LifeScan / OneTouch glucose test strip | `lifescan-glucose-test-strip` | 1981 | private | patented |  |
| LightCycler real-time rapid PCR (Wittwer 1997) | `wittwer-1997-rapid-cycler` | 1997 | academic | patented |  |
| Linx 7900 Continuous Inkjet Coder | `linx-7900-cij-coder` | 2010 | private | patented |  |
| Linx 8900 Continuous Inkjet Coder | `linx-8900-cij-coder` | 2015 | private | patented |  |
| LioniX International TriPleX PIC + Microfluidic Flow Cell | `lionix-triplex-pic-microfluidic` | 2015 | private | patented |  |
| Little Things Factory glass microreactor (LTF-MS, LTF-V) | `little-things-factory-mikroreaktor` | 2005 | private | patented |  |
| Liver hepatocyte sandwich-culture on chip | `bhushan-2013-liver-on-chip` | 2013 | academic | patented |  |
| Lockheed Martin AEGIS / SPY-1 / SPY-6 Radar Microchannel Cooling | `lockheed-martin-aegis-microchannel-cooling` | 1998 | private | patented |  |
| Logos Biosystems LUNA-FX7 Automated Cell Counter | `logos-luna-fx7` | 2020 | private | patented |  |
| Lonza 4D-Nucleofector LV (Large Volume) | `lonza-4d-nucleofector-lv` | 2018 | private | patented |  |
| Lonza Cocoon CAR-T cell therapy platform | `lonza-cocoon-cell-therapy` | 2017 | private | patented |  |
| Lonza FlowPlate microreactor (with Ehrfeld BTS) | `lonza-flowplate` | 2008 | private | patented |  |
| Lonza Nucleofector (classic 2b/2S cuvette platform) | `lonza-nucleofector-classic` | 2001 | private | patented |  |
| Loop-mediated isothermal amplification (LAMP) | `notomi-2000-loop-mediated-isothermal` | 2000 | academic | patented |  |
| Lucira Check-It Flu+COVID Home Test | `lucira-check-it-flu-covid-test` | 2023 | private | patented |  |
| Lucira Health Check It home COVID-19 isothermal molecular test | `lucira-home-covid-test` | 2020 | private | patented |  |
| Lukosz Grating-Coupler Optical Biosensor (PIC ancestor) | `lukosz-1991-grating-coupler-biosensor` | 1991 | academic | open-permissive |  |
| LUMICKS C-Trap Optical Tweezer + Microfluidic Chamber | `lumicks-c-trap-optical-tweezer-microfluidic` | 2014 | private | patented |  |
| LumiraDx HbA1c Cartridge | `lumiradx-hba1c-cartridge` | 2020 | private | patented |  |
| LumiraDx INR Cartridge | `lumiradx-inr-cartridge` | 2021 | private | patented |  |
| LumiraDx Point-of-Care Platform Microfluidic Test Strip | `lumiradx-platform-microfluidic-strip` | 2017 | private | patented |  |
| Lunaphore COMET | `lunaphore-comet-spatial-proteomics` | 2021 | private | patented |  |
| Lung-on-a-chip | `huh-2010-lung-on-chip` | 2010 | academic | patented |  |
| Machine-learning-driven droplet generator design (Lashkaripour 2021/2024) | `lashkaripour-2024-ml-droplet-design` | 2021 | academic | open-permissive |  |
| Made in Abyss Curse-bearing fluid biology and Idofront laboratories | `made-in-abyss-curse-bearing-fluid` | 2017 | fictional | fictional | ✓ |
| Magnetic-activated cell sorting (MACS) | `miltenyi-1990-macs-magnetic-cell-sorting` | 1990 | academic | patented |  |
| Magnetic-bead microvalve and pump | `leslie-2009-magnetic-bead-valve` | 2009 | academic | patented |  |
| Mammoth Biosciences DETECTR BOOST cartridge | `mammoth-detectr-boost-cartridge` | 2022 | private | patented |  |
| Mammoth DETECTR BOOST and Multiplex Cartridge | `mammoth-detectr-cartridge-2024` | 2022 | private | patented |  |
| Manaresi 2003 CMOS DEP Cage Array (DEPArray foundation) | `manaresi-2003-deparray-cmos-foundation` | 2003 | academic | patented |  |
| Manylabs.org Citizen Science Hardware Platform | `manylabs-citizen-science-platform` | 2014 | open | open-permissive | ✓ |
| Manz / Ciba-Geigy original µTAS patent (1990 priority) | `manz-1992-ciba-geigy-mu-tas-patent-original` | 1990 | academic | patented |  |
| Markem-Imaje 9450 Continuous Inkjet Coder | `markem-imaje-9450-cij-coder` | 2014 | private | patented |  |
| Markforged / Digital Metal DM P2500 Binder Jet Printer | `markforged-digital-metal-binder-jet` | 2017 | private | patented |  |
| Mars 2020 MEDA (Mars Environmental Dynamics Analyzer) Fluidic Dust Filter | `mars2020-meda-fluidic-dust-filter` | 2020 | private | unknown |  |
| Mars 2020 MOXIE Solid Oxide Electrolyzer Cell (SOEC) Fluidic Stack | `mars2020-moxie-soec-fluidic-stack` | 2017 | private | patented |  |
| Mars 2020 Perseverance MOXIE (Mars Oxygen In-Situ Resource Utilization Experiment) | `mars2020-moxie-electrolyzer` | 2017 | academic | patented |  |
| Mars 2020 Perseverance PIXL (Planetary Instrument for X-ray Lithochemistry) | `mars2020-pixl-fluidic-flush` | 2020 | academic | public-domain |  |
| Mars 2020 Perseverance SHERLOC (Scanning Habitable Environments with Raman & Luminescence for Organics & Chemicals) | `mars2020-sherloc-spectrometer` | 2018 | academic | public-domain |  |
| Mars Express SPICAM UV/IR Atmospheric Spectrometer | `mars-express-spicam-uv-ir-spectrometer` | 2003 | private | unknown |  |
| Martha Wells Murderbot Diaries HubSystem MedSystem | `wells-murderbot-medsystem` | 2017 | fictional | fictional |  |
| Marvel Asgardian healing room (golden apple regeneration chamber) | `asgard-bio-suit-asgardian` | 2011 | fictional | fictional | ✓ |
| Masimo Rad-57 pulse CO-oximetry sensor | `masimo-rad57-pulse-co-oximetry` | 2005 | private | patented |  |
| Mass Effect 3 Genophage cure synthesis platform | `mass-effect-genophage-cure` | 2012 | fictional | fictional |  |
| Mass Effect Cerberus Lazarus Project (Shepard reconstruction facility) | `mass-effect-cerberus-lazarus-project` | 2010 | fictional | fictional |  |
| Mass Effect medbay automated diagnostics | `mass-effect-medbay` | 2007 | fictional | fictional |  |
| Mass Effect medi-gel topical / injection therapeutic | `mass-effect-medi-gel` | 2007 | fictional | fictional |  |
| Mathies/Quinn 2017 Microchip Capillary Electrophoresis for Mars Amino Acid Detection | `mathies-quinn-2017-microchip-ce-mars-amino-acids` | 2017 | academic | patented |  |
| MaxCyte ATx Flow Electroporation System | `maxcyte-atx-assay-electroporator` | 2018 | private | patented |  |
| MaxCyte GTx Flow Electroporation System | `maxcyte-gtx-gmp-electroporator` | 2014 | private | patented |  |
| MaxCyte STX Scalable Transfection System | `maxcyte-stx-flow-electroporation` | 2007 | private | patented |  |
| MBARI Environmental Sample Processor (ESP) | `mbari-esp-environmental-sample-processor` | 2003 | academic | patented |  |
| MboaLab Open-Source Microbiology Incubator | `mboalab-open-incubator-microbiology` | 2018 | open | open-permissive |  |
| MC10 BioStamp wearable physiological sensor | `mc10-biostamp` | 2014 | private | patented |  |
| Medtronic Guardian Connect / Guardian 3 Sensor | `medtronic-guardian-3-cgm` | 2017 | private | patented |  |
| Medtronic MiniMed 780G insulin pump cartridge | `medtronic-780g-pump` | 2017 | private | patented |  |
| Medtronic Simplera Disposable CGM | `medtronic-simplera-cgm` | 2023 | private | patented |  |
| Memjet thermal silicon-MEMS printhead | `memjet-printhead` | 2007 | private | patented |  |
| Memjet Waterfall MEMS Pagewide Printhead | `memjet-waterfall-mems-printhead` | 2007 | private | patented |  |
| Menarini Silicon Biosystems DEPArray | `menarini-deparray` | 2009 | private | patented |  |
| Menarini Silicon Biosystems DEPArray NxT | `menarini-silicon-biosystems-deparray-nxt` | 2016 | private | patented |  |
| Metafluidics open microfluidics design repository | `metafluidics-platform` | 2018 | open | open-permissive |  |
| Metafluidics open-hardware microfluidics database (disclosure entry) | `metafluidics-database-disclosure` | 2017 | open | open-permissive |  |
| Metafluidics — Open Community Microfluidics Repository (extended) | `metafluidics-2017-community-microfluidics` | 2017 | open | open-permissive |  |
| Mettler-Toledo InPro 6800 / 6850 Dissolved Oxygen Sensor | `mettler-toledo-inpro-6800-do` | 1995 | private | patented |  |
| Mettler-Toledo ParticleTrack G400 FBRM Probe | `mettler-toledo-particletrack-g400-fbrm` | 2010 | private | patented |  |
| Mettler-Toledo ReactIR 700 / 7000 In-Line FTIR | `mettler-toledo-reactir-700-7000-ftir` | 2014 | private | patented |  |
| MGI DNBSEQ-G400 flow cell | `mgi-dnbseq-g400-flow-cell` | 2019 | private | patented |  |
| MGI DNBSEQ-T7 flow cell | `mgi-dnbseq-t7-flow-cell` | 2018 | private | patented |  |
| MICA (Mars In-situ Compound Analyzer) Microfluidic Payload Concept | `mica-mars-in-situ-compound-analyzer-concept` | 2017 | academic | unknown | ✓ |
| Micro total analysis systems. 1. Introduction, theory, and technology | `reyes-2002-utas-history-review` | 2002 | academic | public-domain |  |
| Micro-Manager 2.0 (μManager 2.0) | `micromanager-v2-acquisition-platform` | 2014 | open | open-copyleft |  |
| MicroCHIPS / Microchips Biotech Implantable Drug Reservoir Array | `microchips-biotech-implantable-reservoir` | 1999 | private | patented |  |
| Microdrop Technologies Piezo Microdispenser Heads | `microdrop-technologies-microdispenser` | 1995 | private | patented |  |
| MicroFab Jetlab 4 Life-Sciences Inkjet Print Station | `microfab-jetlab-4-life-sciences-printer` | 2002 | private | patented |  |
| MicroFab MJ-AT/MJ-AB Piezo-Driven Drop-on-Demand Dispenser Head | `microfab-mj-at-piezo-on-demand-dispenser` | 1990 | private | patented |  |
| MicroFab piezo droplet dispenser (industrial) | `microfab-piezo-droplet-dispenser` | 1995 | private | patented |  |
| Microfabricated dielectrophoretic single-cell trap arrays | `voldman-2002-cell-trap-dep-array` | 2002 | academic | patented |  |
| Microfabricated ESI emitter (Figeys 1997) | `figeys-1997-microfabricated-esi` | 1997 | academic | patented |  |
| Microfluidic alginate microbead generation | `choi-weitz-2007-alginate-microbead` | 2007 | academic | patented |  |
| Microfluidic bioreactor for individual yeast cells | `rusconi-2011-microfluidic-bioreactor` | 2011 | academic | public-domain |  |
| Microfluidic bubble logic | `prakash-2007-bubble-logic` | 2007 | academic | public-domain |  |
| Microfluidic cell culture review | `lab-on-chip-mehling-tay-review` | 2014 | academic | public-domain |  |
| Microfluidic cell therapy manufacturing (CAR-T scale-up) | `microfluidic-cell-therapy-manufacturing` | 2018 | academic | patented |  |
| Microfluidic cell-pairing trap arrays for cell fusion | `skelley-2009-cell-pairing-trap` | 2009 | academic | patented |  |
| Microfluidic cell-trap array for single-cell analysis | `di-carlo-2006-cell-trap-array` | 2006 | academic | patented |  |
| microfluidic ChipShop standard glass and thermoplastic chips | `microfluidic-chipshop-fluidic-chips` | 2002 | private | trade-secret |  |
| Microfluidic electroporation for cell therapy manufacturing | `microfluidic-electroporation-cell-therapy` | 2018 | academic | patented |  |
| Microfluidic emulsion droplets in research and applications | `anna-mayer-2005-droplet-fluidics-review` | 2005 | academic | public-domain |  |
| Microfluidic extracellular vesicle / exosome isolation | `microfluidic-extracellular-vesicle-isolation` | 2014 | academic | patented |  |
| Microfluidic flow cytometer architectures (academic) | `berkeley-cellium-flow-cytometer-2009` | 2002 | academic | patented |  |
| Microfluidic large-scale integration | `thorsen-2002-microfluidic-large-scale-integration` | 2002 | academic | patented |  |
| Microfluidic mRNA-LNP vaccine formulation | `microfluidic-mrna-vaccine-formulation` | 2012 | academic | patented |  |
| Microfluidic protein crystallization in nanoliter chambers | `quake-2003-microfluidic-protein-crystallization` | 2002 | academic | patented |  |
| Microfluidic rare-cell isolation (2023-onward methods) | `microfluidic-rare-cell-academic-2023` | 2023 | academic | patented |  |
| Microfluidic soil DNA extraction and pathogen detection | `bridle-2014-soil-microfluidic-extraction` | 2014 | academic | public-domain |  |
| Microfluidics for drug delivery (Langer-Farokhzad lineage) | `microfluidics-drug-delivery-langer` | 2008 | academic | patented |  |
| Microfluidics: fluid physics at the nanoliter scale | `squires-quake-2005-review` | 2005 | academic | public-domain |  |
| Microinnova Engineering modular continuous-flow skid | `microinnova-engineering-modular-skid` | 2008 | private | patented |  |
| Microinnova MICROINNOVA Modular Skid Continuous Manufacturing | `microinnova-modular-skid-continuous` | 2014 | private | patented |  |
| Micromachined Transducers Sourcebook (Kovacs 1998) | `kovacs-1998-bioMEMS-textbook` | 1998 | academic | public-domain |  |
| MicroPython microfluidics controller patterns (community) | `micropython-microfluidics-controller` | 2017 | open | open-permissive |  |
| Microsaic 4500 MiD Compact Mass Spectrometer | `microsaic-4500-mid` | 2014 | private | patented |  |
| Microsaic Systems 4000 MiD Microspray Mass Spectrometer | `microsaic-4000-mid` | 2010 | private | patented |  |
| Microsemi SA.45s Chip-Scale Atomic Clock (CSAC) | `microsemi-csac-sa45s` | 2011 | private | patented |  |
| Microsoft / University of Washington DNA Storage Research Demonstrator | `microsoft-uw-dna-storage` | 2016 | academic | patented |  |
| Microsoft Project Natick + Two-Phase Immersion Cooling Subsea Data Center | `microsoft-natick-twophase-cooling` | 2018 | private | patented |  |
| Microsoft Project Silica + DNA Storage Research Devices | `microsoft-dna-storage-research-device` | 2019 | academic | patented |  |
| MicroTAS 1995 conference founding (van den Berg / Bergveld) | `van-den-berg-1995-mu-tas-conference` | 1995 | academic | public-domain |  |
| Miltenyi CliniMACS Prodigy Adapt module | `miltenyi-prodigy-adapt` | 2023 | private | patented |  |
| Miltenyi CliniMACS Prodigy cell therapy platform | `miltenyi-clinimacs-prodigy` | 2014 | private | patented |  |
| Mimaki JFX600-2531 UV-LED Flatbed Inkjet | `mimaki-jfx600-2531-uv-flatbed` | 2022 | private | patented |  |
| Mimaki TS500P-3200 Industrial Textile Sublimation Printer | `mimaki-tx500p-3200-textile-printer` | 2018 | private | patented |  |
| Mimaki Tx/JV Textile and Wide-Format Inkjet Printer (OEM Piezo Array) | `mimaki-tx-textile-printer-piezo-array` | 2003 | private | patented | ✓ |
| Mindray BC-30 Auto / BC-40 Auto Hematology Analyzers | `mindray-bc-30-auto-hematology` | 2020 | private | patented |  |
| Mindray BC-6800 Hematology Analyzer SF Cube Flow Cell | `mindray-bc-6800-hematology-flow-cell` | 2011 | private | patented |  |
| Miniaturized gas chromatograph on a silicon wafer (Stanford 1979) | `terry-1979-stanford-gas-chromatograph` | 1979 | academic | public-domain |  |
| Miniaturized total chemical analysis system (µ-TAS) | `manz-1990-mu-tas-concept` | 1990 | academic | public-domain |  |
| Miniaturized total chemical analysis systems: a novel concept for chemical sensing | `manz-widmer-1990-utas-framing` | 1990 | academic | public-domain |  |
| Mission Bio Tapestri PRIM (Pre-Integrated Multi-omics) | `mission-bio-tapestri-prim-2024` | 2024 | private | patented | ✓ |
| Mission Bio Tapestri single-cell DNA sequencing | `mission-bio-tapestri` | 2018 | private | patented |  |
| MIT Center for Bits and Atoms / Fab Lab Network | `openfoundry-cba-fab-lab-network` | 2002 | open | open-permissive |  |
| Moderna mRNA Continuous-Process Manufacturing Platform | `moderna-mrna-continuous-process` | 2020 | private | patented | ✓ |
| Molecular Assemblies FAMS Enzymatic DNA Synthesis | `molecular-assemblies-fams-synthesis` | 2018 | private | patented | ✓ |
| MOST — Open-Source 3-D Platform for Low-Cost Scientific Instrument Ecosystem | `zhang-pearce-2016-most-platform-instrument-ecosystem` | 2016 | open | open-copyleft |  |
| Mother machine: high-throughput single-bacterium tracking | `ferry-2011-mother-machine` | 2010 | academic | public-domain |  |
| Mott Corporation porous-metal microreactor inserts (GasShield, FlowMott) | `mott-corporation-porous-metal-flow-reactor` | 2003 | private | patented |  |
| MSL Sample Analysis at Mars (SAM) Wet Chemistry Cell with MTBSTFA Derivatization | `msl-sam-wet-chemistry-cell` | 2012 | academic | public-domain |  |
| Multi-resolution DLP-SLA for 2 µm microfluidic channels | `miner-2026-multi-resolution-3d-printing-microfluidics` | 2026 | academic | public-domain |  |
| Multiply Labs robotic cell therapy manufacturing | `multiply-labs-robotic-cgt` | 2022 | private | patented |  |
| Mutoh ValueJet 1638UH / 1638UR UV-LED Inkjet Printer | `mutoh-valuejet-1638uh-uv-led-printer` | 2014 | private | patented |  |
| Mutoh XpertJet XPJ-460PRT Direct-to-Garment Printer | `mutoh-xpj-460prt-direct-to-garment` | 2017 | private | patented | ✓ |
| Namocell Hana Single Cell Dispenser | `namocell-hana-single-cell-dispenser` | 2017 | private | patented |  |
| Namocell Pala Single Cell Dispenser | `namocell-pala-single-cell-dispenser` | 2020 | private | patented |  |
| Nano Dimension DragonFly LDM 3D Circuit Printer | `nano-dimension-dragonfly-ldm-3d-circuit-printer` | 2017 | private | patented |  |
| NanoCellect WOLF Cell Sorter | `nanocellect-wolf-microfluidic-sorter` | 2017 | private | patented |  |
| Nanofluidic scattering microscopy (NSM) | `spackova-2022-nanofluidic-scattering-microscopy` | 2022 | academic | public-domain |  |
| NanoString CosMx Spatial Molecular Imager | `nanostring-cosmx` | 2022 | private | patented |  |
| NanoString CosMx Whole Transcriptome Atlas (WTA) | `nanostring-cosmx-wta-2024` | 2024 | private | patented |  |
| NanoString GeoMx Digital Spatial Profiler | `nanostring-geomx` | 2019 | private | patented |  |
| Natera Signatera ctDNA Collection Tube | `natera-signatera-collection-cartridge` | 2017 | private | patented | ✓ |
| Neal Asher Polity autodoc | `asher-polity-autodoc` | 2002 | fictional | fictional |  |
| Neal Asher Spatterjay viral-induced longevity fluidics | `asher-spatterjay-viral-fluidics` | 2002 | fictional | fictional |  |
| Neal Stephenson Diamond Age matter compiler | `stephenson-diamond-age-matter-compiler` | 1995 | fictional | fictional |  |
| Neal Stephenson Seveneves Cradle / Endurance medical infrastructure | `stephenson-seveneves-medical` | 2015 | fictional | fictional |  |
| Nemaura SugarBEAT Transdermal CGM Patch | `nemaura-sugarbeat-transdermal` | 2016 | private | patented |  |
| Neogen ANSR Isothermal Pathogen Detection System | `neogen-ansr-isothermal-pathogen` | 2013 | private | patented |  |
| Neogen Atlas food pathogen detection cartridge | `neogen-atlas-pathogen` | 2008 | private | patented |  |
| Neogen GeneQuence DNA Pathogen Detection System | `neogen-genequence-dna-pathogen` | 2006 | private | patented |  |
| Neogen Reveal Lateral Flow Test Family | `neogen-reveal-lateral-flow-allergen` | 1999 | private | patented |  |
| Neon Genesis Evangelion LCL entry-plug fluid immersion | `evangelion-lcl-entry-plug` | 1995 | fictional | fictional |  |
| Neuralink R1 Surgical Robot for Threaded Microelectrode Insertion | `neuralink-r1-surgical-robot` | 2019 | private | patented |  |
| Neuropixels High-Density Silicon Probe | `neuropixels-imec-hhmi` | 2017 | academic | patented |  |
| Nexcelom Cellaca PLX (and MX) Image Cytometer | `nexcelom-cellaca-plx` | 2018 | private | patented |  |
| NIH MPS / NCATS microphysiological systems program | `huh-bhatia-2018-mps-roadmap` | 2012 | academic | public-domain |  |
| NinjaPCR Open Thermocycler | `ninjapcr-open-thermocycler` | 2018 | open | open-permissive |  |
| Nix Hydration Biosensor | `nix-hydration-biosensor` | 2021 | private | patented |  |
| NOA-81 (Norland Optical Adhesive) microfluidic chip fabrication | `bartolo-2008-noa-microfluidics` | 2008 | academic | public-domain |  |
| Notion Systems n.jet Display Manufacturing Inkjet | `notion-systems-njet-display-inkjet` | 2014 | private | patented |  |
| Nova StatStrip Glucose/Ketone Hospital Test Strip | `nova-statstrip-glucose-strip` | 2006 | private | patented |  |
| nScrypt 3Dn-Tissue bioprinter | `nscrypt-3dn-tissue` | 2014 | private | patented |  |
| Numenera Auto-doctor cypher and biotech artifacts | `numenera-autodoctor-cypher` | 2013 | fictional | fictional |  |
| NUS microfluidic platforms (Lim group, Chen group) | `nus-microfluidics-lim` | 2008 | academic | patented |  |
| Octavia Butler Lilith's Brood Oankali biological technology (living ships and tools) | `butler-oankali-bio-technology` | 1987 | fictional | fictional |  |
| OKI Microline OEM Piezo Inkjet Printhead Use | `okidata-led-vs-inkjet-microline-printhead` | 2005 | private | patented | ✓ |
| OLS Bio CASY Cell Counter and Analyzer (formerly Innovatis CASY-TT) | `ols-bio-casy-tt-cell-counter` | 1991 | private | patented |  |
| On Demand Pharmaceuticals Pharmacy-on-Demand (PoD) refrigerator-scale continuous manufacturing | `on-demand-pharmaceuticals-pharmacy-on-demand` | 2018 | private | patented |  |
| On-chip electrokinetic injection patent (Manz / Ciba-Geigy 1993) | `manz-1993-on-chip-injection-patent` | 1993 | academic | patented |  |
| One-Punch Man Dr. Genus House of Evolution biological augmentation lab | `one-punch-man-doctor-genus` | 2009 | fictional | fictional |  |
| Open Bioeconomy Lab | `open-bioeconomy-lab-africa` | 2018 | open | public-domain |  |
| Open Insulin Foundation | `open-insulin-foundation` | 2015 | open | open-copyleft |  |
| Open microfluidic firmware in Rust (community 2024-onward) | `open-microfluidics-2024-rust-firmware` | 2023 | open | open-permissive |  |
| Open PID controllers for microfluidic flow / pressure / temperature | `open-pid-controller-microfluidics` | 2020 | open | open-permissive |  |
| Open replicator-style microfluidic pump (3D-printed peristaltic) | `open-microfluidic-pump-pdf-replicator` | 2019 | open | open-permissive |  |
| Open-JIP — Open Chlorophyll Fluorometer (OJIP transient) | `open-jip-chlorophyll-fluorometer` | 2020 | open | open-permissive |  |
| Open-source toolkits for microfluidics design and simulation | `open-source-toolkit-for-microfluidics` | 2018 | open | open-permissive |  |
| OpenFlexure Delta Stage | `openflexure-deltastage-2022` | 2022 | open | open-copyleft |  |
| OpenFlexure microfluidics-friendly XYZ stage variant | `open-flexure-microfluidics-fork` | 2020 | open | open-permissive |  |
| OpenFlexure Microscope | `openflexure-microscope` | 2016 | open | open-permissive |  |
| OpenFlexure Microscope v7 — High-Resolution Lab Variant | `openflexure-microscope-v7` | 2020 | open | open-permissive |  |
| OpenFlexure pump (open-hardware peristaltic) | `open-flexure-pump` | 2020 | open | open-permissive |  |
| OpenFlexure Pump (Stirling et al. 2020) | `openflexure-pump-stirling-2020` | 2020 | open | open-copyleft |  |
| OpenLH open-source liquid handler | `openlh-liquid-handler` | 2018 | open | open-permissive |  |
| OpenMTA — Open Material Transfer Agreement | `openmta-open-material-transfer-agreement` | 2018 | open | open-permissive |  |
| OpenMV Cam Open-Source Machine Vision Module | `openmv-machine-vision-cam` | 2014 | open | open-permissive |  |
| OpenPCR open-source thermal cycler | `openpcr-thermal-cycler` | 2010 | open | open-permissive |  |
| OpenPCR Open-Source Thermal Cycler (Chai Bio / Perl + Salzberg) | `openpcr-chai-2010-thermal-cycler` | 2010 | open | open-permissive |  |
| OpenPlant — Cambridge / John Innes Synthetic-Biology Initiative | `openplant-cambridge-norwich-synthetic` | 2014 | open | open-permissive |  |
| OpenRAMAN Open-Source Raman Spectrometer | `openraman-low-cost-raman-spectrometer` | 2020 | open | open-permissive |  |
| OpenRAMAN Starter Edition | `openraman-starter-edition-2023` | 2023 | open | open-permissive | ✓ |
| OpenSPIM light-sheet microscope | `openspim-microscope` | 2013 | open | open-permissive |  |
| openSPIN-EM Open Spinning-Disc / Light-Sheet Hybrid | `openspin-em-2023` | 2023 | open | open-permissive | ✓ |
| Opentrons Flex liquid handler (2023 successor) | `opentrons-flex-liquid-handler` | 2023 | open | open-permissive |  |
| Opentrons OT-2 liquid handler | `opentrons-ot2` | 2018 | open | open-permissive |  |
| Opentrons OT-2 open-source liquid handler | `opentrons-ot-2-liquid-handler` | 2018 | open | open-permissive |  |
| OpenWetWare Community Wiki | `openwetware-mit-wiki` | 2005 | open | open-permissive |  |
| optek-Danulat AF26 Absorption / Turbidity Sensor | `optek-af26-turbidity` | 2005 | private | patented |  |
| Optomec Aerosol Jet Printed Electronics System | `optomec-aerosol-jet-printer` | 2004 | private | patented |  |
| OraSure rapid HIV test cassette (lateral flow) | `orasure-quickflex-cartridge` | 1995 | private | patented |  |
| Organoid multi-omics on chip (2024 academic work) | `fan-2024-organoid-multiomics` | 2024 | academic | patented |  |
| Organoid-on-chip disease modeling (2023-2026 academic work) | `huang-2024-organoid-on-chip-disease-model` | 2023 | academic | patented |  |
| Organoid-on-chip integration (Clevers 2020 review) | `organoid-on-chip-clevers-2020` | 2020 | academic | patented |  |
| Organovo NovoGen MMX 3D bioprinter | `organovo-novogen-bioprinter` | 2009 | academic | patented |  |
| Organovo NovoGen MMX Bioprinter Dual Extrusion Bioprinthead | `organovo-novogen-mmx-bioprinter-dual-head` | 2009 | private | patented |  |
| Ori Biotech IRO cell therapy manufacturing platform | `ori-biotech-iro` | 2019 | private | patented |  |
| OSIRIS-REx TAGSAM (Touch-and-Go Sample Acquisition Mechanism) | `osiris-rex-tagsam-bennu-sample` | 2017 | academic | patented |  |
| OSTE (off-stoichiometry thiol-ene) microfluidic substrates | `carlborg-2011-oste-microfluidics` | 2011 | academic | patented |  |
| Oxford Nanopore MinION flow cell | `oxford-nanopore-minion` | 2014 | private | patented |  |
| Oxford Nanopore R10.4.1 flow cell | `ont-r10-4-1-flow-cell` | 2022 | private | patented |  |
| PacBio Onso short-read sequencer flow cell | `pacbio-onso-shortread` | 2022 | private | patented |  |
| PacBio Revio SMRT Cell | `pacbio-revio-smrt-cell` | 2022 | private | patented |  |
| Pall Allegro STR / single-use fluidic train | `pall-allegro-stt` | 2010 | private | patented |  |
| Pall iCellis 1000 Fixed-Bed Bioreactor | `pall-icellis-1000-fixed-bed-bioreactor` | 2015 | private | patented |  |
| Pall iCellis Fixed-Bed Bioreactor (Nano / 500) | `pall-icellis-fixed-bed` | 2010 | private | patented |  |
| Paper-based microfluidic devices for distributed point-of-care diagnostics | `martinez-2007-paper-microfluidics` | 2007 | academic | patented |  |
| Paradromics Connexus Direct Data Interface | `paradromics-connexus` | 2020 | private | patented |  |
| Paraffin-based thermally-actuated microvalves | `liu-2002-paraffin-thermal-valve` | 2002 | academic | patented |  |
| Parse Biosciences Evercode split-pool single-cell kit | `parse-biosciences-evercode` | 2018 | private | patented |  |
| Passengers (2016) Avalon autodoc medical pod | `passengers-2016-medbay` | 2016 | fictional | fictional |  |
| PCR (Mullis 1985) | `nelson-polymerase-chain-reaction-1985` | 1985 | academic | patented |  |
| Pearce Lab MOST Open Scientific Hardware Suite | `pearce-most-open-hardware-suite` | 2012 | open | open-copyleft |  |
| Pearce-lab Open Syringe Pump v2 — Large-Format / NEMA17 Variant | `wijnen-pearce-2014-syringe-pump-v2-12mm` | 2014 | open | open-copyleft |  |
| PEG grafting on PDMS for surface passivation | `eddington-2008-pdms-peg-grafting` | 2003 | academic | public-domain |  |
| PEGDA hydrogel photopatterning in microfluidic channels | `chen-2003-pegda-hydrogel-photopatterning` | 2003 | academic | patented |  |
| Peking University microfluidic biotechnology (Cao group) | `peking-u-microfluidics-cao` | 2005 | academic | patented |  |
| PerkinElmer LabChip GXII Touch / EZ Reader | `perkinelmer-labchip-gxii-ez-reader` | 2002 | private | patented |  |
| Peter F. Hamilton ANA Governance distributed-consciousness substrate (Void Trilogy) | `hamilton-ana-governance-fluidics` | 2007 | fictional | fictional | ✓ |
| Peter F. Hamilton Edenist affinity-bonding and longevity clinic (Night's Dawn) | `hamilton-edenist-affinity-clinic` | 1996 | fictional | fictional |  |
| Peter F. Hamilton Highmotive medical pods | `hamilton-highmotive-medical-pod` | 2004 | fictional | fictional |  |
| Peter F. Hamilton Lazaroid longevity / immortality treatment (Adamist civilization) | `hamilton-lazaroid-treatment` | 1996 | fictional | fictional |  |
| Peter F. Hamilton Memorycell neural-backup implant (Commonwealth Saga) | `hamilton-memorycell-neural-backup` | 2004 | fictional | fictional |  |
| Pfizer ECO/ECOnTab Continuous Tableting Platform | `pfizer-eco-econtab-continuous-tableting` | 2017 | private | patented |  |
| Pfizer Portable Continuous Miniature and Modular (PCMM) plant | `pfizer-pcmm-portable-on-demand` | 2014 | private | patented |  |
| Phoenix Mars Lander MECA Wet Chemistry Laboratory (WCL) | `phoenix-meca-wet-chemistry-lab` | 2008 | academic | public-domain |  |
| Piezoelectric drop-on-demand inkjet (Kyser-Sears 1976) | `kyser-sears-1976-piezo-inkjet` | 1976 | academic | patented |  |
| Pinched injection on glass CE microchips | `jacobson-1994-pinched-injection` | 1994 | academic | public-domain |  |
| Pioreactor | `pioreactor-open-bioreactor` | 2021 | open | open-permissive |  |
| Poly(dimethylsiloxane) as a material for fabricating microfluidic devices (McDonald & Whitesides 2002) | `mcdonald-whitesides-2002-pdms-review` | 2002 | academic | public-domain |  |
| Poseidon open-source syringe pump | `poseidon-syringe-pump` | 2018 | open | open-permissive |  |
| Poseidon — Open Syringe Pump and Microscope System | `edmondson-2018-poseidon-syringe-pump-system` | 2019 | open | open-permissive |  |
| POSTECH microfluidic platforms (Kahp-Yang Suh / Korean lineage) | `postech-microfluidics-suh` | 2002 | academic | patented |  |
| PowerCell Sweden microchannel fuel processor reformer | `powercell-microchannel-fuel-cell-reformer` | 2008 | private | patented |  |
| Precision Nanosystems NanoAssemblr (microfluidic LNP manufacturing) | `precision-nanosystems-nanoassemblr` | 2010 | private | patented |  |
| Profusa Lumee implantable hydrogel oxygen sensor | `profusa-lumee-implantable` | 2014 | private | patented |  |
| Promega Maxwell RSC 48 Instrument | `promega-maxwell-rsc-48-extraction` | 2016 | private | patented |  |
| Promega Maxwell RSC Magnetic Bead Nucleic Acid Extractor | `promega-maxwell-rsc-magnetic-extraction` | 2014 | private | patented |  |
| Promega PowerPlex Fusion 6C STR Amplification Cartridge | `promega-powerplex-fusion-6c-cartridge` | 2015 | private | patented |  |
| Promega Spectrum Compact CE System | `promega-spectrum-compact-ce` | 2020 | private | patented |  |
| ProSep Electrochemical Membrane Reactor (EMR) | `prosep-electrochemical-membrane-reactor` | 2015 | private | patented | ✓ |
| Psaltis Group EPFL Optofluidic Microscope and Sensor Platform | `psaltis-epfl-optofluidic-platform` | 2008 | academic | patented |  |
| PSoC-Stat Single-Chip Open Potentiostat | `lopin-2018-psoc-stat-potentiostat` | 2018 | open | open-permissive |  |
| Psycho-Pass Sibyl System brain-immersion fluidic substrate | `psycho-pass-sibyl-brain-immersion` | 2012 | fictional | fictional |  |
| Public Lab DIY spectrometer | `public-lab-spectrometer` | 2010 | open | open-permissive |  |
| Public Lab Foldable Papercraft Mini-Spectrometer | `publiclab-foldable-spectrometer-2014` | 2014 | open | public-domain |  |
| Public Lab Papercraft Spectrometer v2.0 | `publiclab-papercraft-spectrometer-v2` | 2017 | open | public-domain |  |
| Pumpy peristaltic pump (open-hardware) | `ufluidix-pumpy` | 2017 | open | open-permissive |  |
| Pyrosequencing (Ronaghi 1996) | `ronaghi-1996-pyrosequencing` | 1996 | academic | patented |  |
| QIAGEN QIAcube HT Sample Prep | `qiagen-qiacube-ht-extraction` | 2013 | private | patented |  |
| Qiagen QIAreach POC molecular cartridge | `qiagen-qiareach-cartridge` | 2020 | private | patented |  |
| QIAGEN QIAsymphony SP/AS | `qiagen-qiasymphony-sp-as` | 2008 | private | patented |  |
| Quake monolithic pneumatic membrane valve and pump | `unger-2000-quake-monolithic-membrane-valve` | 2000 | academic | patented |  |
| Quanterix Simoa HD-X / HD-1 Single-Molecule Array Bead Cartridge | `quanterix-simoa-hd-x-bead-cartridge` | 2011 | private | patented |  |
| Quanterix Simoa HD-X Platform | `quanterix-simoa-hd-x-platform` | 2017 | private | patented |  |
| Quantum Diamond Technologies NV-Diamond Cancer-Cell Magnetic-Bead Detector | `lukin-quantum-diamond-technologies` | 2017 | private | patented |  |
| Quantum-Si Platinum protein sequencer | `quantum-si-platinum` | 2022 | private | patented |  |
| Quidel Sofia 2 fluorescent immunoassay analyzer | `quidel-sofia-2` | 2014 | private | patented |  |
| Quidel Sofia rapid immunoassay cartridge | `quidel-sofia-cartridge` | 2010 | private | patented |  |
| Quidel Triage MeterPro Immunoassay Cartridge | `quidel-triage-meterpro-fluorescence-cartridge` | 1995 | private | patented |  |
| Radial capillary-array electrophoresis chip | `mathies-1995-radial-cap-array` | 1995 | academic | patented |  |
| Radiometer ABL90 FLEX Blood Gas Analyzer Sensor Cassette | `radiometer-abl90-flex-cartridge` | 2009 | private | patented |  |
| RainDance Technologies droplet platform (acquired by Bio-Rad) | `raindance-bio-rad-acquisition` | 2008 | private | patented |  |
| Ramez Naam Apex / Crux Nexus implant fluidic neural communication | `naam-apex-implant-comm` | 2013 | fictional | fictional |  |
| Ramez Naam Nexus trilogy nano-pharmaceutical brain interface | `naam-nexus-trilogy-implant` | 2012 | fictional | fictional |  |
| Ramsey integrated chip-MS extensions (post-1996) | `ramsey-2000-integrated-chip-ms` | 2000 | academic | patented |  |
| Rapid prototyping of microfluidic systems in PDMS | `duffy-1998-pdms-soft-lithography-microfluidics` | 1998 | academic | public-domain |  |
| Ray Bradbury There Will Come Soft Rains automated household fluidics | `bradbury-soft-rains-automated-kitchen` | 1950 | fictional | fictional |  |
| Raytheon AESA Radar T/R Module Microchannel Cooling | `raytheon-aesa-microchannel-cooling` | 2005 | private | patented |  |
| Readily3D Tomolite volumetric bioprinter | `readily3d-tomolite` | 2020 | private | patented |  |
| Real-time DNA sequencing from single polymerase molecules (PacBio SMRT) | `eid-2009-pacbio-smrt` | 2009 | academic | patented |  |
| Recombinase polymerase amplification (RPA) | `rolando-recombinase-polymerase-amplification` | 2006 | academic | patented |  |
| Refeyn TwoMP / OneMP mass photometer with microfluidic flow cell | `refeyn-twomp-mass-photometry` | 2018 | private | patented |  |
| RegenHU 3DDiscovery / R-GEN bioprinter | `regenhu-3d-discovery-bioplotter` | 2012 | private | patented |  |
| Replenish Inc. Ophthalmic MEMS Drug Delivery Micropump | `replenish-mems-ophthalmic-micropump` | 2008 | private | patented |  |
| Repligen KrosFlo tangential flow filtration system | `repligen-krosflo-tff` | 2005 | private | patented |  |
| Repligen XCell ATF alternating tangential flow cell-retention device | `repligen-xcell-atf` | 2002 | private | patented |  |
| Resident Evil T-Virus / G-Virus injection vials and Umbrella labs | `resident-evil-virus-injection-vial` | 1996 | fictional | fictional |  |
| Resilience CGT Manufacturing Platform | `resilience-cgt-manufacturing-platform` | 2020 | private | trade-secret | ✓ |
| Resolve Bioscience Molecular Cartography Pro | `resolve-bioscience-molecular-cartography-pro` | 2024 | private | patented | ✓ |
| Resolve Biosciences Molecular Cartography | `resolve-bioscience-molecular-cartography` | 2020 | private | patented |  |
| Respite SAW Nebulizer (RMIT) | `rezk-yeo-2012-saw-nebulizer` | 2012 | academic | patented |  |
| Returnal medical bay (recursion-tied diagnostic + restoration) | `returnal-medical-bay` | 2021 | fictional | fictional | ✓ |
| Ribbon Biolabs Long DNA Synthesis Platform | `ribbon-biolabs-rna-ligation-synthesis` | 2020 | private | patented | ✓ |
| Rick and Morty portal fluid synthesis | `rick-and-morty-portal-fluid` | 2013 | fictional | fictional |  |
| Ricoh GH2220 Silicon Piezo Industrial Printhead | `ricoh-gh2220-silicon-piezo-printhead` | 2013 | private | patented |  |
| Ricoh MH5420/MH5440 Stainless-Steel Recirculating Industrial Printhead | `ricoh-mh5440-stainless-recirculating-printhead` | 2014 | private | patented |  |
| Ricoh Ri 1000/2000/6000 Direct-to-Garment Printer Series | `ricoh-ri-garment-printer-series` | 2018 | private | patented |  |
| RISO ComColor GD-Series Fast Cut-Sheet Inkjet | `riso-comcolor-gd-series-fast-cut-sheet-inkjet` | 2014 | private | patented |  |
| Rissin & Walt Femtoliter Microwell Array (Simoa Foundation) | `rissin-2008-femtoliter-array-foundation` | 2006 | academic | patented |  |
| Rivnay-Lab Organic Iontronic Neural Interface | `rivnay-iontronic-neural-interface` | 2018 | academic | open-permissive |  |
| RMIT/Monash SAW Droplet Microfluidic Platform | `yeo-friend-2014-saw-droplet-platform` | 2014 | academic | open-permissive |  |
| Robert A. Heinlein Stranger in a Strange Land medical units | `heinlein-stranger-strange-land-medical` | 1961 | fictional | fictional |  |
| Roche Cobas 6000 Modular Analyzer Fluidic Track | `roche-cobas-6000-modular-fluidics` | 2007 | private | patented |  |
| Roche cobas c clinical chemistry analyzer cartridge | `roche-cobas-c-cartridge` | 2007 | private | patented |  |
| Roche cobas Liat point-of-care cartridge | `roche-cobas-liat-cartridge` | 2009 | private | patented |  |
| Roche Cobas u 411 Urine Test Strip Reflectance Fluidic Path | `roche-cobas-u-411-urinalysis-strip-fluidics` | 2009 | private | patented |  |
| Roche Elecsys Electrochemiluminescence Reagent Cassette | `roche-elecsys-ecl-reagent-cassette` | 1996 | private | patented |  |
| Roche LightCycler 480 Real-Time PCR System | `roche-lightcycler-480-multiwell-plate` | 2006 | private | patented |  |
| Roche MagNA Pure 24 System | `roche-magnapure-24-extraction` | 2015 | private | patented |  |
| Roche MagNA Pure 96 Magnetic-Bead Nucleic Acid Extraction Cartridge | `roche-magna-pure-96-extraction-cartridge` | 2009 | private | patented |  |
| Roche MagNA Pure 96 System | `roche-magnapure-96-extraction` | 2010 | private | patented |  |
| Rockley Photonics Bioptx Multi-Analyte Wearable | `rockley-photonics-bioptx-multianalyte` | 2021 | private | patented | ✓ |
| Roland DG SOLJET DX Eco-Solvent Wide-Format Piezo Printhead | `roland-dg-soljet-dx-piezo-printhead` | 2001 | private | patented |  |
| Roland VersaUV LEJ-2/LEF-2/LEC2 UV Inkjet Series | `roland-versauv-lej2-flatbed-uv` | 2019 | private | patented |  |
| Romer Labs AgraStrip Mycotoxin Lateral Flow Tests | `romer-labs-agrastrip-mycotoxin-lateral-flow` | 2010 | private | patented |  |
| Romer Labs FluoroQuant Mycotoxin Quantitation System | `romer-labs-fluoroquant-mycotoxin-quant` | 2008 | private | patented |  |
| RoosterBio xeno-free hMSC manufacturing platform | `roosterbio-rooster-platform` | 2014 | private | patented |  |
| S2 Genomics Singulator tissue dissociation system | `s2-genomics-singulator` | 2019 | private | unknown | ✓ |
| Sachs (MIT) Three-Dimensional Printing / Binder Jetting Patent | `sachs-mit-1993-three-dimensional-printing` | 1993 | academic | patented |  |
| Saga (Vaughan/Staples) Landfall / Wreath medical infrastructure | `saga-comics-magic-tech-medical` | 2012 | fictional | fictional |  |
| Sage Science PippinHT cassette electrophoresis | `sage-pippinht-electrophoresis` | 2014 | private | patented |  |
| Sartorius ambr 15 microbioreactor system | `sartorius-ambr-15` | 2009 | private | patented |  |
| Sartorius ambr 250 high-throughput single-use bioreactor | `sartorius-ambr-250` | 2013 | private | patented |  |
| Sartorius ambr 250 Modular Single-Use Bioreactor | `sartorius-ambr-250-modular-bioreactor` | 2014 | private | patented |  |
| Sartorius BioPAT MFCS / Biostat Bioprocess Analytics | `sartorius-bioprocess-analytics-bionet` | 2015 | private | patented | ✓ |
| Sartorius BioPAT Process Analytical Technology Suite | `sartorius-biopat-pat-framework` | 2010 | private | patented |  |
| Sartorius BioSMB continuous multi-column chromatography | `sartorius-biosmb-continuous-chromatography` | 2010 | private | patented |  |
| Sartorius BIOSTAT B-DCU Bench-Scale Bioreactor | `sartorius-biostat-b-dcu-bioreactor` | 2008 | private | patented |  |
| Sartorius FlexAct Single-Use Process Skid | `sartorius-flexact-skid` | 2010 | private | patented |  |
| Sartorius Flexsafe RM single-use rocking bag and BIOSTAT RM | `sartorius-flexsafe-rm` | 2014 | private | patented |  |
| Scale Biosciences single-cell split-pool kit | `scale-bio-split-pool-kit` | 2022 | private | patented |  |
| ScaleReady G-Rex Scale-Out Process System (GSPS) | `scaleready-gsps` | 2021 | private | patented |  |
| Science Jubilee Lab-Automation Fork | `sonderegger-2024-science-jubilee` | 2024 | open | open-permissive |  |
| SCIEX Eksigent ekspert nanoLC 400 / 425 Nanoflow Liquid Chromatography | `sciex-eksigent-nanolc` | 2002 | private | patented |  |
| SD Biosensor STANDARD Q rapid antigen test | `sd-biosensor-rapid-antigen` | 2017 | private | patented |  |
| Sebia Capillarys hemoglobinopathy CE analyzer | `sebia-capillarys-3` | 2005 | private | patented |  |
| Seiko Instruments (SII Printek) RC1536 Industrial Piezo Printhead | `seiko-instruments-rc1536-printhead` | 2010 | private | patented |  |
| Self-assembled monolayers (Ulman 1996 review) | `ulman-1996-self-assembled-monolayers` | 1991 | academic | public-domain |  |
| Self-optimizing continuous flow chemistry | `reizman-2015-self-optimizing-flow` | 2015 | academic | public-domain |  |
| Senseonics Eversense Implantable Continuous Glucose Monitor | `senseonics-eversense-implantable-cgm` | 2016 | private | patented |  |
| Sepragen QuantaSep / ProSep Radial-Flow Chromatography Column | `sepragen-quantasep-radial-chromatography` | 1989 | private | patented |  |
| SetPoint Medical Implantable Vagus Nerve Stimulator | `setpoint-medical-vagus-stimulator` | 2012 | private | patented |  |
| Seveneves orbital microfluidic biology suite | `seveneves-stratosphere-microfluidic-lab` | 2015 | fictional | fictional |  |
| Severance medical procedures and 'wellness' depictions | `severance-medical-floor-procedures` | 2022 | fictional | fictional |  |
| Shadowrun cyberware/bioware fluidic-interface suite (datajacks, wired reflexes, cybereyes) | `shadowrun-cyberware-bioware-suite` | 1989 | fictional | fictional |  |
| Shadowrun street-clinic bioware / cyberware installation | `shadowrun-bioware-clinic` | 1989 | fictional | fictional |  |
| Sherlock Biosciences INSPECTR cartridge | `sherlock-biosciences-inspectr` | 2023 | private | patented |  |
| Sherlock Biosciences SHERLOCK Cartridge | `sherlock-biosciences-sherlock-cartridge-2024` | 2024 | private | patented |  |
| SHERLOCK CRISPR-Cas13 nucleic acid detection | `gootenberg-zhang-2017-sherlock` | 2017 | academic | patented |  |
| SHERLOCK-on-Paper Lateral-Flow CRISPR Diagnostic | `sherlock-on-paper-zhang-watson` | 2018 | academic | patented |  |
| Shimadzu LCMS-IT-TOF Ion-Trap Time-of-Flight Mass Spectrometer | `shimadzu-it-ms` | 2006 | private | patented |  |
| SHINE CRISPR-on-paper diagnostic | `myhrvold-zhang-2018-shine-crispr-on-paper` | 2018 | academic | patented |  |
| SHUGA POC molecular diagnostic cartridge (2024 demonstration) | `kaminski-shuga-cartridge-2024` | 2024 | academic | patented |  |
| Siemens Atellica CH 930 Clinical Chemistry Analyzer Cuvette Ring | `siemens-atellica-ch-930-cuvette-ring` | 2017 | private | patented |  |
| Siemens Atellica IM 1300 Immunoassay Analyzer Acridinium Cuvette Module | `siemens-atellica-im-1300-immunoassay` | 2017 | private | patented |  |
| Siemens epoc Blood Analysis System cartridge | `epoc-blood-gas-analyzer` | 2006 | private | patented |  |
| Siemens RAPIDPoint 500 Blood Gas Cartridge | `siemens-rapidpoint-500-blood-gas-cartridge` | 2008 | private | patented |  |
| Siemens RAPIDPoint 500e Blood Gas Analyzer | `siemens-rapidpoint-500e-blood-gas` | 2018 | private | patented |  |
| Sigma-Aldrich (Merck) Flow Chemistry product kits and reagent supports | `merck-sigma-aldrich-flow-chemistry-kits` | 2009 | private | patented |  |
| Silicon as a mechanical material (Petersen 1982) | `petersen-1982-silicon-mechanical-material` | 1982 | academic | public-domain |  |
| Silicon micromachined valve survey (Branebjerg 1996) | `branebjerg-1995-silicon-valve-survey` | 1996 | academic | public-domain |  |
| Silicon piezoelectric micropump (Van Lintel 1988) | `van-lintel-1988-silicon-piezo-pump` | 1988 | academic | patented |  |
| Silicon piezoelectric peristaltic micropump (Smits 1989) | `smits-1989-piezo-peristaltic-pump` | 1989 | academic | patented |  |
| Silicon-based miniature PCR thermal cycler (Northrup 1993) | `northrup-1993-silicon-pcr-microreactor` | 1993 | academic | patented |  |
| Silo (TV adaptation) implant fluid handling depictions | `silo-implant-chip` | 2023 | fictional | fictional |  |
| Single molecule arrays (Simoa) for ultrasensitive immunoassay | `rissin-2010-quanterix-simoa` | 2010 | academic | patented |  |
| Single-molecule DNA sequencing through nanopore | `clarke-2009-nanopore-sequencing` | 2009 | academic | patented |  |
| Singleron Matrix microwell single-cell platform | `singleron-matrix-microwell` | 2020 | private | unknown | ✓ |
| Singleron Matrix sCircle Barcoding | `singleron-matrix-scircle-barcoding` | 2023 | private | patented | ✓ |
| Singular Genomics G4 sequencer flow cell | `singular-genomics-g4` | 2022 | private | patented |  |
| Singulex Erenna single-molecule counting immunoassay | `todd-singulex-erenna-2006` | 2006 | academic | patented |  |
| Six Million Dollar Man bionic-diagnostic medical scanner | `six-million-dollar-man-bionic-diagnostics` | 1973 | fictional | fictional |  |
| Slide-seq spatial transcriptomics on bead arrays | `rodriques-2019-slide-seq` | 2019 | academic | patented |  |
| Smartphone-based microscopy and microfluidic imaging (Ozcan 2010) | `ozcan-2010-smartphone-microscopy` | 2010 | academic | patented |  |
| Smartphone-based photonic-crystal biosensor | `zhang-cunningham-2014-smartphone-photonic-detection` | 2013 | academic | patented |  |
| Smartphone-based POC diagnostics review | `contreras-naranjo-2017-smartphone-microfluidic-review` | 2017 | academic | public-domain |  |
| Smartphone-based semen analysis (Kanakasabapathy 2017) | `kanakasabapathy-shafiee-2017-cellphone-fertility` | 2017 | academic | patented |  |
| Smiths Detection IONSCAN Ion Mobility Spectrometer (Trace Detection) | `smiths-detection-ionscan` | 1995 | private | patented |  |
| Snapdragon Chemistry continuous-manufacturing platform (acquired by Cambrex 2021) | `snapdragon-cambrex-continuous-manufacturing` | 2014 | private | patented |  |
| Snow Crash bioluminescent fluidic computing | `snow-crash-bioluminescent-fluidic` | 1992 | fictional | fictional |  |
| Soft lithography review (Xia & Whitesides 1998) | `xia-whitesides-1998-soft-lithography-review` | 1998 | academic | public-domain |  |
| Soft, skin-mounted epidermal microfluidic device for sweat collection and analysis | `koh-rogers-2016-epidermal-microfluidic` | 2016 | academic | patented |  |
| Solaris Biotech Jupiter Bioreactor / Fermenter | `solaris-jupiter-custom-bioreactor` | 2010 | private | trade-secret | ✓ |
| SOLID (Signs Of Life Detector) Antibody Microarray Platform | `nasa-solid-signs-of-life-detector` | 2008 | academic | unknown |  |
| SonoSep Technologies Acoustic Cell Separator | `sonosep-acoustic-cell-separation` | 2002 | private | patented |  |
| Sony SH800 Microfluidic Cell Sorter | `sony-sh800-microfluidic-cell-sorter` | 2013 | private | patented |  |
| SparkFun / Pumping Lemma open microfluidic 'brick' connectors | `sparkfun-microfluidic-bricks` | 2017 | open | public-domain | ✓ |
| Spatial multi-omics extensions (2023-2026 academic) | `wu-zhang-2023-spatial-multiomics` | 2023 | academic | patented |  |
| Spatial transcriptomics (Visium / Slide-seq ancestors) | `staahl-2016-spatial-transcriptomics` | 2016 | academic | patented |  |
| Spectra Inc. Drop-on-Demand Piezo Printhead (Lebanon, NH) | `spectra-1984-lebanon-piezo-printhead` | 1984 | private | patented |  |
| Sphere Fluidics Cyto-Mine Single-Cell Analysis System | `sphere-fluidics-cyto-mine-acoustic-droplet-sorting` | 2017 | private | patented |  |
| Sphere Fluidics Cyto-Mine single-cell screening platform | `sphere-fluidics-cytomine` | 2017 | private | patented |  |
| SPT Labtech Mosquito nanoliter pipettor | `ttp-mosquito-nanoliter-dispenser` | 2003 | private | patented |  |
| Squid open-hardware microscopy platform | `squid-microscope` | 2020 | open | open-permissive |  |
| Squid — Simplifying Quantitative Imaging Platform Development and Deployment | `li-prakash-2020-squid-imaging-platform` | 2020 | open | open-permissive |  |
| SQZ AAC (Activating Antigen Carrier) platform | `sqz-aac-antigen-presenting-cells` | 2017 | private | patented |  |
| SQZ Biotechnologies Cell Squeeze platform | `sqz-biotech-cell-squeeze-platform` | 2013 | private | patented |  |
| Stago STA R Max Coagulation Analyzer Cuvette Ball Mixer | `stago-sta-r-max-coag-fluidics` | 2007 | private | patented |  |
| Standard BioTools (formerly Fluidigm) C1 single-cell genomics IFC | `standard-biotools-csg-fluidigm` | 2013 | private | patented |  |
| Standard BioTools Hyperion XTi imaging mass cytometer | `standard-biotools-hyperion-xti` | 2023 | private | patented |  |
| Standing surface acoustic wave (SSAW) acoustic tweezers | `ding-2012-saw-acoustic-tweezers` | 2012 | academic | patented |  |
| Stanford Free Genes Project (BioBricks Foundation) | `stanford-free-genes-project` | 2017 | open | public-domain |  |
| Stanisław Lem The Cyberiad — Trurl's matter-compiler machines | `lem-cyberiad-matter-compiler` | 1965 | fictional | fictional |  |
| Star Citizen medical equipment (medical beds, MedPens, hospital ships) | `star-citizen-medical-equipment` | 2018 | fictional | fictional |  |
| Star Trek autodoc / sickbay surgical bed | `star-trek-autodoc-tos-tng` | 1987 | fictional | fictional |  |
| Star Trek Borg maturation chamber and assimilation-tubule fluid delivery | `star-trek-borg-maturation-chamber` | 1989 | fictional | fictional |  |
| Star Trek DS9 Dr. Mora Pol biological research laboratory (Bajoran Institute) | `star-trek-ds9-mora-pol-lab` | 1993 | fictional | fictional | ✓ |
| Star Trek Enterprise Dr. Phlox's biological-creature pharmacopoeia | `star-trek-ent-phlox-menagerie` | 2001 | fictional | fictional |  |
| Star Trek hypospray needle-free injector | `star-trek-hypospray` | 1966 | fictional | fictional |  |
| Star Trek medical tricorder | `star-trek-tricorder-medical` | 1966 | fictional | fictional |  |
| Star Trek molecular replicator | `star-trek-replicator` | 1987 | fictional | fictional |  |
| Star Trek TNG/DS9/VOY surgical biobed | `star-trek-tng-biobed` | 1987 | fictional | fictional |  |
| Star Trek TOS Enterprise sickbay biobed | `star-trek-tos-biobed` | 1966 | fictional | fictional |  |
| Star Trek VOY EMH emergency medical kit | `star-trek-voy-emh-emergency-kit` | 1995 | fictional | fictional |  |
| Star Wars 2-1B medical droid | `star-wars-2-1b-medical-droid` | 1980 | fictional | fictional |  |
| Star Wars bacta tank / kolto tank | `star-wars-bacta-tank` | 1980 | fictional | fictional |  |
| Stardust Aerogel Comet/Interstellar Dust Sample Collector | `stardust-aerogel-comet-sample-collector` | 1999 | academic | unknown |  |
| Stargate Atlantis Wraith feeding hand and stunner extraction biology | `stargate-atlantis-wraith-feeding-hand` | 2004 | fictional | fictional | ✓ |
| Stargate SG-1 Asgard biological consciousness-transfer device | `stargate-asgard-bio-transfer` | 2000 | fictional | fictional |  |
| Stargate SG-1 Goa'uld sarcophagus (resurrection / regeneration device) | `stargate-goauld-sarcophagus` | 1997 | fictional | fictional |  |
| Stemme 1979 Thermal Inkjet Priority Patent (Sweden) | `stemme-1979-thermal-inkjet-priority-patent` | 1979 | private | patented |  |
| Stop-flow lithography and Beebe geometry | `beebe-2000-stop-flow` | 2000 | academic | patented |  |
| Stratasys / Objet PolyJet Multi-Material UV-Cure Printhead | `stratasys-objet-polyjet-printhead` | 1999 | private | patented |  |
| Sun Chemical Streamline / SunJet Inkjet Ink Family | `sun-chemical-streamline-inkjet-ink` | 2002 | private | patented | ✓ |
| SUSS MicroTec PiXDRO Inkjet for Semiconductor and Display | `suss-microtec-pixdro-inkjet` | 2010 | private | patented |  |
| Sweet (Stanford) Electrostatically-Deflected Continuous Inkjet Oscillograph | `sweet-1965-electrostatic-modulation-cij` | 1965 | academic | patented |  |
| Sweet 1965 Continuous-Inkjet Deflection Patent (extended) | `sweet-1965-deflection-patent-extended` | 1965 | private | patented |  |
| Synchron Stentrode Endovascular Brain-Computer Interface | `synchron-stentrode` | 2016 | private | patented |  |
| Syntegon Versynta Microbatch / Combotec Filler | `syntegon-versynta-microbatch-filler` | 2017 | private | patented |  |
| Synthego CRISPR ePool / Eclipse Platform | `synthego-crispr-epool` | 2018 | private | patented | ✓ |
| Synthetic biology / circuit-design tools (microfluidics-relevant) | `khalil-collins-2010-synthetic-biology-toolkit` | 2010 | academic | public-domain |  |
| Syrris Asia and Africa flow-chemistry platform | `syrris-flow-chemistry` | 2007 | private | patented |  |
| Syrris Asia and Asia 320 modular flow chemistry platform | `syrris-asia-platform` | 2010 | private | patented |  |
| Syrris Asia FLUX Electrochemistry Module | `syrris-asia-flux-electrochemistry` | 2019 | private | patented |  |
| Sysmex CS-2500 / CN-6000 Coagulation Analyzer Multi-Wavelength Cuvette | `sysmex-cs-2500-coag-automated` | 2014 | private | patented |  |
| Sysmex hematology analyzer flow cell | `sysmex-cbc-cartridge` | 1968 | private | patented |  |
| Sysmex XN-9000 Modular Hematology Track Sample-Aspiration Subsystem | `sysmex-xn-9000-track-hematology` | 2011 | private | patented |  |
| T&R Biofab IB3D / 3DX Multi-Head Bioprinter | `tr-biofab-ib3d-bioprinter` | 2015 | private | patented | ✓ |
| T&R Biofab IB3D / Bio-Architect bioprinter | `tnr-biofab-ib3d` | 2014 | private | patented |  |
| T&R Biofab IB3D Bioprinter Printhead | `tnr-biofab-ib3d-bioprinter-head` | 2018 | private | patented |  |
| T2 Biosystems T2Dx cartridge | `t2-biosystems-cartridge` | 2014 | private | patented |  |
| Takara Bio iCell8 cx Single-Cell System (Wafergen) | `takara-icell8-cx` | 2014 | private | patented |  |
| Talis One COVID-19 Test Cartridge | `talis-one-covid-19-cartridge` | 2021 | private | patented |  |
| Tandem Diabetes t:slim X2 insulin pump cartridge | `tandem-tslim-x2-cartridge` | 2012 | private | patented |  |
| TaqMan probe RT-PCR (Livak 1995) | `livak-genmark-1995-rt-pcr-foundations` | 1995 | academic | patented |  |
| Taylor-Aris dispersion in pipe flow | `taylor-aris-dispersion-1953` | 1953 | academic | public-domain |  |
| Tecan Cavro MagniFlex Multi-Channel Pipettor Block | `tecan-cavro-magni-flex-pipettor-block` | 2010 | private | patented |  |
| Tecan DreamPrep NGS Sample Prep | `tecan-dreamprep-ngs` | 2018 | private | patented |  |
| Tecan Fluent automation workstation with Cavro syringe pumps | `tecan-fluent-cavro` | 2014 | private | patented |  |
| Tecan Resolvex i300 Bead Handling System | `tecan-resolvex-i300-magnetic` | 2021 | private | patented |  |
| Ted Chiang Exhalation argon-air brain chemistry | `chiang-exhalation-argon-brain` | 2008 | fictional | fictional |  |
| Telesis Bio BioXp 9600 Benchtop DNA Synthesis | `telesis-bioxp-9600-benchtop-synthesis` | 2022 | private | patented |  |
| Temperature-controlled chip holder with integrated electrodes for NSS | `altenburger-2026-temperature-controlled-chip-holder` | 2026 | academic | public-domain |  |
| Tessera Therapeutics Gene Writing Manufacturing | `tessera-therapeutics-gene-writing` | 2020 | private | patented | ✓ |
| ThalesNano H-Cube continuous-flow hydrogenation reactor | `thalesnano-h-cube-flow-hydrogenation` | 2003 | private | patented |  |
| ThalesNano X-Cube, Phoenix Flow Reactor, Ice-Cube, and Gas Module | `thalesnano-x-cube-phoenix-icecube-gasmodule` | 2008 | private | patented |  |
| The Andromeda Strain isolation/analysis lab | `andromeda-strain-isolation-chamber` | 1969 | fictional | fictional |  |
| The Expanse Mao biohack injectors / protomolecule delivery | `expanse-mao-biohack-injectors` | 2015 | fictional | fictional |  |
| The Expanse protomolecule containment / analysis vat | `expanse-protomolecule-vat` | 2015 | fictional | fictional |  |
| The future of microfluidic point-of-care diagnostic devices (Ren & Lee) | `ren-2013-microfluidics-disposability` | 2013 | academic | public-domain |  |
| The Last of Us cordyceps detection field tools | `last-of-us-fungal-infection-detection` | 2013 | fictional | fictional |  |
| The Matrix human battery pod fluid-immersion + Tetris IV feed | `matrix-pod-fluid-immersion` | 1999 | fictional | fictional |  |
| The Matrix Nebuchadnezzar / hovership operating room | `matrix-sentinel-hovership-medbay` | 1999 | fictional | fictional |  |
| The motion and precipitation of suspensoids in divergent electric fields (dielectrophoresis foundation) | `pohl-1951-dielectrophoresis-foundation` | 1951 | academic | public-domain |  |
| The ODIN DIY Genetic Engineering Kits | `the-odin-diy-genetic-eng-kits` | 2015 | open | open-permissive |  |
| The origins and the future of microfluidics | `whitesides-2007-origins-future-microfluidics` | 2007 | academic | public-domain |  |
| The origins and the future of microfluidics (Whitesides 2006) | `whitesides-2006-nature-microfluidics-review` | 2006 | academic | public-domain |  |
| The Outer Worlds Unreliable medical bay and corporate medical kiosks | `outer-worlds-medical-bay` | 2019 | fictional | fictional |  |
| The present and future role of microfluidics in biomedical research | `sackmann-2014-microfluidics-medicine-review` | 2014 | academic | public-domain |  |
| Theranos Edison / miniLab cartridge (claimed) | `theranos-promised-cartridge` | 2003 | private | patented |  |
| Thermal bubble-jet foundation (Endo / Canon, 1979) | `endo-1979-canon-thermal-bubble-jet-foundation` | 1979 | academic | patented |  |
| Thermo Fisher Applied Biosystems RapidHIT ID System | `thermofisher-rapidhit-id-forensic-dna` | 2012 | private | patented |  |
| Thermo Fisher Countess 3 / Countess 3 FL Automated Cell Counter | `thermofisher-countess-3` | 2020 | private | patented |  |
| Thermo Fisher KingFisher Magnetic Particle Processor | `thermofisher-kingfisher-magnetic-bead-handler` | 1996 | private | patented |  |
| Thermo Fisher MagMAX Magnetic Bead Extraction System | `thermofisher-magmax-extraction` | 2008 | private | patented |  |
| Thermo Fisher Neon NxT Electroporator | `thermofisher-neon-nxt-electroporator` | 2022 | private | patented |  |
| Thermo Fisher Phadia 2500 Allergy/Autoimmune ImmunoCAP Cartridge | `thermo-fisher-phadia-2500-immunoassay` | 2008 | private | patented |  |
| Thermo Fisher TaqPath / Applied Biosystems QuantStudio cartridge | `thermo-taqpath-cartridge` | 2010 | private | patented |  |
| ThermoFisher 3500 / 3500xL Genetic Analyzer CE | `thermofisher-3500-ce` | 2010 | private | patented |  |
| ThermoFisher AutoMate Express Forensic DNA Extraction | `thermofisher-automate-express-extraction` | 2010 | private | patented |  |
| ThermoFisher Convergence Forensic Allele Calling and Casework Software 3.4 | `thermofisher-convergence-dx-3-4` | 2019 | private | patented |  |
| ThermoFisher KingFisher Apex Magnetic Particle Processor | `thermofisher-kingfisher-apex-extraction` | 2019 | private | patented |  |
| ThermoFisher KingFisher Duo Prime Magnetic Particle Processor | `thermofisher-kingfisher-duo-prime` | 2014 | private | patented |  |
| ThermoFisher RapidHIT 200 Human DNA Identification System | `thermofisher-rapidhit-200` | 2012 | private | patented |  |
| ThermoFisher RapidHIT ID DNA Booking System | `thermofisher-rapidhit-id` | 2017 | private | patented |  |
| Thermoresponsive hydrogel microvalves | `oh-2006-thermoresponsive-microvalve` | 2006 | academic | public-domain |  |
| ThinkCyte VisionSort / Image-Activated Cell Sorter (Ota 2018) | `ota-thinkcyte-2018-image-activated-sort` | 2018 | academic | patented |  |
| Three-Body Problem (Netflix) medical and laboratory depictions | `three-body-problem-medical` | 2024 | fictional | fictional |  |
| Tidepool Loop DIY Closed-Loop Insulin Algorithm | `tidepool-loop-diy-closed-loop` | 2016 | open | open-permissive |  |
| Tiefenthaler & Lukosz IOS-1 Optical Waveguide Sensor | `tiefenthaler-lukosz-1989-IOS-1-grating` | 1989 | academic | patented | ✓ |
| Tonejet Electrostatic Charged-Particle Drop-on-Demand Printhead | `tonejet-electrostatic-printhead` | 1993 | private | patented |  |
| Tony Jun Huang Lab Tunable Acoustic Tweezers | `huang-penn-state-2014-tsaw-acoustic-tweezers` | 2014 | academic | patented |  |
| Toshiba TBA series clinical chemistry analyzer | `toshiba-clinical-analyzer` | 1990 | private | patented |  |
| Toshiba TEC CF3/CF3R Recirculating Piezo Industrial Printhead | `toshiba-tec-cf3-recirculating-printhead` | 2017 | private | patented |  |
| Touchlight Genetics Doggybone DNA (dbDNA) Platform | `touchlight-doggybone-dna` | 2010 | private | patented |  |
| Touchlight Genetics doggybone DNA (dbDNA) Synthesis | `touchlight-doggybone-dna-microfluidic` | 2014 | private | patented |  |
| Transmetropolitan personal maker / matter compiler | `transmetropolitan-maker-matter-compiler` | 1997 | fictional | fictional |  |
| Trasis miniAllInOne Compact PET Tracer Synthesizer | `trasis-mini-allinone` | 2014 | private | patented |  |
| Trauma Center / Trauma Team (Atlus) automated surgical interfaces | `trauma-team-international` | 2005 | fictional | fictional |  |
| Traveller (Classic) medical autodoc / low berth | `traveller-medical-autodoc` | 1977 | fictional | fictional |  |
| Traveller Far Trader medical bay (Classic Traveller and Mongoose editions) | `traveller-far-trader-medical-bay` | 1977 | fictional | fictional |  |
| Triastek MED (Melt Extrusion Deposition) 3D-Printing Platform | `triastek-med-3d-printing-platform` | 2020 | private | patented |  |
| Trident ITW PixelJet Piezo Printhead (extended) | `trident-itw-pixeljet-piezo-printhead` | 1995 | private | patented |  |
| Trident UltraJet / 768Jet Industrial Piezo Printhead | `trident-itw-ultrajet-piezo-printhead` | 1985 | private | patented |  |
| Trigun / Gungrave biological resurrection apparatus (Vash + Beyond the Grave) | `trigun-vash-gungrave-fluid-resurrection` | 1995 | fictional | fictional |  |
| Trinity Biotech Premier Hb9210 HbA1c analyzer cartridge | `trinity-biotech-premier-hba1c` | 2009 | private | patented |  |
| Tsinghua University microfluidics program | `tsinghua-microfluidics-program` | 2000 | academic | patented |  |
| TTP Mirus / Sphere Fluidics droplet picoinjector | `ttp-mirus` | 2010 | private | patented |  |
| Twist Bioscience + Western Digital DNA Storage Demonstration (DNA Data Storage Alliance) | `twist-western-digital-dna-storage` | 2023 | private | patented |  |
| Twist Bioscience Cell Engineering (Twist Cellomics) | `twist-bioscience-cellomics` | 2016 | private | patented |  |
| Twist Bioscience Cellomics Single-Cell Barcoding Kit | `twist-bioscience-cellomics-singlecell` | 2024 | private | patented | ✓ |
| Twist Bioscience Silicon Chip DNA Synthesis Platform | `twist-bioscience-silicon-oligo-synthesis` | 2016 | private | patented |  |
| UCL Goyanes Group Printlets (3D-Printed Personalized Tablets) | `ucl-goyanes-printlets-3d-tablets` | 2014 | academic | open-permissive |  |
| uFluidix microfluidic chip fabrication services | `ufluidix-foundry-services` | 2014 | open | open-permissive |  |
| Ultima Genomics UG 100 wafer-format flow cell | `ultima-genomics-ug100-wafer` | 2022 | private | patented |  |
| Ultima Genomics UG100 W-series Wafer Flow Cell | `ultima-genomics-100ug-100w-wafer-flowcell` | 2024 | private | patented |  |
| Uniqsis FlowSyn modular flow chemistry reactor | `uniqsis-flowsyn` | 2007 | private | patented |  |
| Univercells scale-X Bioreactor (carbo / hydro / nitro) | `univercells-scale-x-bioreactor` | 2017 | private | patented |  |
| Univercells scale-X for AAV / Viral Vaccine Manufacturing | `univercells-scalex-vaccine-aav` | 2017 | private | patented |  |
| Upload (Amazon) afterlife head-scanning fluid system | `upload-amazon-2020` | 2020 | fictional | fictional |  |
| Ursula K. Le Guin Left Hand of Darkness Gethenian kemmer biology | `le-guin-left-hand-gethenian-biology` | 1969 | fictional | fictional | ✓ |
| UWED — Universal Wireless Electrochemical Detector for Smartphones | `ainla-2018-uwed-wireless-potentiostat` | 2018 | open | open-permissive |  |
| Vaisala Viewpoint Humidity Monitoring for Tableting | `vaisala-viewpoint-tableting-humidity` | 2015 | private | patented | ✓ |
| Vanrx SA25 Aseptic Filling Workcell (now Cytiva Microcell Vial Filler) | `vanrx-sa25-aseptic-workcell` | 2015 | private | patented |  |
| Vapourtec continuous-flow chemistry system | `vapourtec-flow-chemistry` | 2003 | private | patented |  |
| Vapourtec Ion Electrochemistry Flow Module | `vapourtec-ion-electrochemistry-module` | 2018 | private | patented |  |
| Vapourtec R-Series with UV-150 photochemical reactor and V-3 peristaltic pump | `vapourtec-r-series-uv-150` | 2014 | private | patented |  |
| Vaught/Cloutier HP Thermal-Bubble Inkjet Patent (US4490728) | `vaught-cloutier-1981-hp-thermal-bubble-jet` | 1981 | private | patented |  |
| Vaxxas High-Density Microarray Patch (HD-MAP) | `vaxxas-hd-map-microneedle` | 2010 | private | patented |  |
| Velocys microchannel Fischer-Tropsch reactor for GTL/PTL/BTL | `velocys-microchannel-fischer-tropsch` | 2001 | private | patented |  |
| Velocys SiC-Coated Microchannel Fischer-Tropsch Catalyst Monolith | `velocys-sic-monolith-catalyst` | 2009 | private | patented |  |
| Ventana DISCOVERY ULTRA automated IHC stainer | `ventana-discovery-ihc` | 2010 | private | patented |  |
| Veracyte Decipher GRID Sample Prep Cartridge | `veracyte-decipher-prep-cartridge` | 2018 | private | patented | ✓ |
| Vernor Vinge A Fire Upon the Deep medical pods | `vinge-fire-upon-deep-medical` | 1992 | fictional | fictional |  |
| Vernor Vinge Qeng Ho cryosleep coffin (A Deepness in the Sky) | `vinge-deepness-qengho-cryosleep` | 1999 | fictional | fictional |  |
| Vernor Vinge Rainbows End mass-printed pharmaceuticals | `vinge-rainbows-end-pharma-printer` | 2006 | fictional | fictional |  |
| Vernor Vinge Slow Zone repair / cold-sleep pods (A Fire Upon the Deep) | `vinge-fire-upon-deep-slowzone-pods` | 1992 | fictional | fictional |  |
| Vernor Vinge Spider 'Focus' serum (A Deepness in the Sky) | `vinge-deepness-spider-focus-serum` | 1999 | fictional | fictional |  |
| Verve Therapeutics In Vivo Base-Editing LNP Manufacturing | `verve-therapeutics-in-vivo-base-editing` | 2021 | private | patented |  |
| Vescent Photonics Compact Cs Vapor Cell Atomic Clock | `vescent-csac` | 2018 | private | patented | ✓ |
| VGXI Plasmid DNA Manufacturing | `vgxi-plasmid-manufacturing` | 2003 | private | trade-secret | ✓ |
| Videojet Binary Array Continuous Inkjet Coding Printhead | `videojet-binary-array-cij-coding` | 1969 | private | patented |  |
| Viking 1/2 GCMS and Biology Package | `viking-1976-gcms-biology-experiment` | 1976 | academic | public-domain |  |
| Visby Medical PCR cartridge | `visby-medical-cartridge` | 2018 | private | patented |  |
| Visby Medical Sexual Health Test Cartridge | `visby-medical-sexual-health-test-cartridge` | 2021 | private | patented |  |
| VITE (Venus In-Situ Test Evaluator) Microfluidic Concept | `vite-venus-in-situ-test-evaluator-concept` | 2020 | academic | unknown | ✓ |
| Vivy Fluorite Eye's Song NiaLand medical bots | `vivy-niaa-medical-bots` | 2021 | fictional | fictional |  |
| Vizgen MERFISH 2 Encoding Chemistry | `vizgen-merfish-2-chemistry` | 2024 | private | patented | ✓ |
| Vizgen MERSCOPE platform | `vizgen-merscope` | 2021 | private | patented |  |
| Vizgen MERSCOPE Ultra | `vizgen-merscope-ultra` | 2024 | private | patented |  |
| Volta Labs Desktop digital microfluidics library prep | `volta-labs-desktop` | 2023 | private | patented |  |
| Vortex chip for label-free CTC isolation (Sollier 2014) | `sollier-2014-vortex-chip` | 2014 | academic | patented |  |
| Voxeljet VX Binder-Jetting Sand and Polymer Printer | `voxeljet-binder-jet-printer` | 1999 | private | patented |  |
| Vroman effect: time-resolved competitive protein adsorption | `vroman-effect-1962` | 1962 | academic | public-domain |  |
| Wallace H. Coulter 1953 Impedance Particle/Cell Counting Patent (Coulter Principle) | `coulter-1953-impedance-cell-counting-patent` | 1953 | private | patented |  |
| Walsworth Lab NV-Diamond Wide-Field Magnetic Imaging Microscope | `walsworth-nv-magnetometer` | 2013 | academic | patented |  |
| WandaVision / MCU Vision body-fluid replication | `wandavision-vision-fluid-replication` | 2015 | fictional | fictional |  |
| Waters ACQUITY UPLC Ultra-Performance Liquid Chromatography System | `waters-acquity-uplc` | 2004 | private | patented |  |
| Waters ionKey/MS chip | `waters-iongenius-chip` | 2014 | private | patented |  |
| Waters SELECT SERIES Cyclic Ion Mobility MS | `waters-select-series-cyclic-im` | 2019 | private | patented |  |
| Waters Xevo TQ Triple Quadrupole Mass Spectrometer | `waters-xevo-tq-ms` | 2008 | private | patented |  |
| Wax-printed paper microfluidics for low-cost diagnostics | `franssila-2010-paper-fluidic-pcl` | 2009 | academic | public-domain |  |
| Wearable sweat sensors with multiplexed biosensing | `gao-2016-sweat-sensor-wearable` | 2016 | academic | patented |  |
| Werfen ACL TOP 750 Coagulation Analyzer Optical Cuvette Train | `werfen-acl-top-750-coag-optical` | 2010 | private | patented |  |
| Werfen GEM Premier 5000 blood gas cartridge | `instrumentation-laboratory-gem-premier` | 2002 | private | patented |  |
| Werfen GEM Premier 5000 Blood Gas Multi-Use Cartridge | `werfen-gem-premier-5000-cartridge` | 2015 | private | patented |  |
| Westworld host fluid-systems and fabrication tanks | `westworld-host-fluid-systems` | 2016 | fictional | fictional |  |
| Wijnen / Pearce Lab Open-Source Syringe Pump | `wijnen-pearce-2014-open-syringe-pump` | 2014 | open | open-copyleft |  |
| William Gibson Neuromancer Chiba City clinic biohacking infrastructure | `gibson-neuromancer-biohack` | 1984 | fictional | fictional |  |
| William Gibson The Peripheral fabrication printer | `gibson-peripheral-printer` | 2014 | fictional | fictional |  |
| Wilson Wolf G-Rex 2.0 Gas-Permeable Cell Expansion Device | `wilson-wolf-grex-2-0` | 2020 | private | patented |  |
| Wilson Wolf G-Rex gas-permeable bioreactor | `wilson-wolf-grex` | 2007 | private | patented |  |
| Wisdom Panel Canine DNA Test Kit | `wisdom-panel-canine-genetic-kit` | 2007 | private | patented |  |
| WISSARD / SALSA Subglacial Antarctic Microbial Samplers | `wissard-salsa-subglacial-microbe-sampler` | 2014 | academic | open-permissive |  |
| Wittbrodt–Pearce 2015 Open-Source Enzymatic Nitrate Photometer | `wittbrodt-2015-open-nitrate-photometer` | 2015 | open | open-copyleft |  |
| Wondfo Finecare FIA Meter Plus | `wondfo-finecare-fia-meter` | 2014 | private | patented |  |
| X-Men Mr. Sinister cloning vats (Madelyne Pryor and beyond) | `xmen-mr-sinister-cloning-vats` | 1986 | fictional | fictional |  |
| X-Men Weapon X program adamantium-bonding tank (Wolverine origin) | `xmen-weapon-x-adamantium-tank` | 1991 | fictional | fictional |  |
| Xaar Shared-Wall Shear-Mode Piezo Printhead | `xaar-1988-shared-wall-shear-mode-printhead` | 1988 | private | patented |  |
| Y: The Last Man Dr. Mann's reproductive cloning facility | `y-last-man-sperm-bank` | 2002 | fictional | fictional |  |
| Yeo & Friend Acoustofluidics Review (ARFM 2014 + AnnRev BME 2018) | `yeo-2018-acoustofluidic-review` | 2014 | academic | open-permissive |  |
| Ypsomed mylife YpsoPump Insulin Pump | `ypsomed-ypsopump` | 2016 | private | patented |  |
| Zenodo / OSF open microfluidic protocol repositories | `open-protocols-zenodo-microfluidics` | 2018 | open | open-permissive |  |
| Zoetis VETSCAN HM5 Hematology Analyzer | `zoetis-vetscan-hm5-hematology` | 2010 | private | patented |  |
| Zoetis VETSCAN i-STAT Alinity v | `zoetis-vetscan-istat-alinity-v` | 2020 | private | patented |  |
| Zoetis Vetscan Imagyst AI Diagnostic Platform (extended) | `zoetis-imagyst-ai-fecal-blood-smear` | 2020 | private | patented |  |
| Zoetis Vetscan IMAGYST AI-augmented veterinary diagnostics | `zoetis-vetscan-imagyst` | 2020 | private | patented |  |
| Zoetis VETSCAN UA Urinalysis Analyzer | `zoetis-vetscan-ua-urinalysis-strip` | 2018 | private | patented |  |
| Zoltan/Clevite Squeeze-Tube Drop-on-Demand Piezo Inkjet | `zoltan-1972-clevite-squeeze-tube-inkjet` | 1972 | private | patented |  |
| µManager open-source microscopy software | `micromanager-imaging` | 2005 | open | open-permissive |  |
| µPADs II / III: Systematic Whitesides disclosures | `whitesides-2010-mu-pads-systematic` | 2010 | academic | patented |  |
