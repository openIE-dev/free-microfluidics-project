---
title: fabrication-multilayer-lamination
parent: Cross-cuts
layout: default
---

# Cross-cut: `fabrication-multilayer-lamination`

**14 corpus entries disclose this subsystem.**

Earliest disclosure: 1997

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## IMM Institut für Mikrotechnik Mainz modular microreactors (slit/interdigital/Caterpillar) (1997)

- **id**: `imm-mainz-modular-microreactors`
- **corpus**: academic
- **device class**: mixer-component
- **creator**: Institut für Mikrotechnik Mainz GmbH (now part of Fraunhofer ICT-IMM)
- **disclosure**: Ehrfeld, W.; Golbig, K.; Hessel, V.; Löwe, H.; Richter, T. 'Characterization of mixing in micromixers by a test reaction: single mixing units and mixer arrays' Ind. Eng. Chem. Res. 1999, 38, 1075–1082; IMM Mainz technical report 1997; DE19536856A1 1995 priority
- **ip status**: patented
- **prior art notes**: IMM Mainz is the canonical academic-industrial bridge for European microreactors. Discloses (a) interdigital multilamination as a numerable industrial mixing primitive — alternating thin feed streams produce diffusion-limited mixing at orders-of-magnitude reduced length scale; (b) the 'slit-and-interdigital' mixer (SIMM) family covering laboratory through 3 m³/h production; (c) the canonical Caterpillar split-recombine pattern later commercialized by Ehrfeld BTS; (d) the entire architectural language of 'numbering up' (parallel modules) versus 'scaling up' (larger channels). Should be cited against later patent claims to interdigital lamination mixers, multilamination plate-stack mixers, and slit-focused multistream contactors.

## Quake monolithic pneumatic membrane valve and pump (2000)

- **id**: `unger-2000-quake-monolithic-membrane-valve`
- **corpus**: academic
- **device class**: valve-component
- **creator**: Stephen Quake group, Caltech
- **disclosure**: Unger, M. A.; Chou, H.-P.; Thorsen, T.; Scherer, A.; Quake, S. R. Monolithic microfabricated valves and pumps by multilayer soft lithography. Science 2000, 288, 113–116. DOI: 10.1126/science.288.5463.113
- **ip status**: patented
- **prior art notes**: Foundational disclosure of pneumatically actuated elastomeric membrane valves built monolithically into a multilayer PDMS chip. By cyclically actuating three valves in series, a peristaltic pump is realized. This is the architectural ancestor of essentially every subsequent on-chip pneumatic valve and pump. Anticipates: pneumatic membrane valve (control channel + thin membrane + flow channel), peristaltic pumping by sequential valve actuation, large-scale integrated chip-scale fluidic circuits. Subsequent papers (Nordin 2017, Sanchez Noriega 2021) re-implement the same architecture in 3D-printed photopolymer.

## Velocys microchannel Fischer-Tropsch reactor for GTL/PTL/BTL (2001)

- **id**: `velocys-microchannel-fischer-tropsch`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Velocys Inc. (PNNL spinout, US/UK)
- **disclosure**: Tonkovich, A. L.; Perry, S.; Wang, Y.; Qiu, D.; LaPlante, T.; Rogers, W. A. 'Microchannel process technology for compact methane steam reforming' Chem. Eng. Sci. 2004, 59, 4819–4824; Velocys Inc. (formerly Oxford Catalysts Group) founding 2001 from PNNL spinout; ENVIA Energy Oklahoma City GTL plant commissioning 2017
- **ip status**: patented
- **prior art notes**: Canonical industrial deployment of microchannel chemistry to a multi-thousand-kilogram-per-day production application. Discloses (a) diffusion-bonded stainless-steel laminate microchannel reactor with alternating reaction and coolant layers — the architectural pattern that made plant-scale microchannel reactors economically viable; (b) catalyst-coated structured washcoat within sub-millimeter channels for highly exothermic Fischer-Tropsch synthesis; (c) the 'numbering-up at scale' execution of stacking thousands of identical channels in parallel inside a single reactor block; (d) commercial demonstration at ENVIA Energy Oklahoma City. Anticipates patent claims to laminated metal microchannel reactors for highly exothermic gas-to-liquids chemistry, and to catalyst-coated microchannel architecture for compact GTL plants.

## Microfluidic large-scale integration (2002)

- **id**: `thorsen-2002-microfluidic-large-scale-integration`
- **corpus**: academic
- **device class**: lab-on-chip
- **creator**: Quake group, Caltech
- **disclosure**: Thorsen, T.; Maerkl, S. J.; Quake, S. R. Microfluidic large-scale integration. Science 2002, 298, 580–584. DOI: 10.1126/science.1076996
- **ip status**: patented
- **prior art notes**: Demonstrated 'microfluidic large-scale integration' — thousands of Quake valves operated as binary multiplexers to address hundreds of chambers from a few control lines. The conceptual analog of VLSI for microfluidics. Anticipates: hierarchical valve multiplexing for chamber-array addressing (n chambers from O(log n) control lines), and the architectural model that underlies Fluidigm IFCs and most chip-scale microfluidic automation. Companion to Unger 2000 valve disclosure; together they define MLSI.

## Fluidigm Dynamic Array Integrated Fluidic Circuit (2003)

- **id**: `fluidigm-dynamic-array-ifc`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Fluidigm Corp. (now Standard BioTools)
- **disclosure**: Fluidigm Corp. (now Standard BioTools) Integrated Fluidic Circuit / Dynamic Array. https://www.standardbio.com/products/instruments-and-consumables and Fluidigm IFC patent family.
- **ip status**: patented
- **prior art notes**: Commercial implementation of Quake / Thorsen MLSI (microfluidic large-scale integration) for high-throughput qPCR, single-cell qPCR, and digital PCR. Anticipates: direct architectural lineage from Unger 2000 + Thorsen 2002 to commercial multi-thousand-well qPCR arrays. The corpus exists in part because of the IP positions Fluidigm built around this architecture.

## Air Products microchannel hydrocarbon-to-hydrogen bench reactor (microHCBR) (2003)

- **id**: `air-products-microhcbr-hydrogen-reactor`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Air Products and Chemicals Inc. in collaboration with Pacific Northwest National Laboratory (PNNL)
- **disclosure**: Whyatt, G. A.; TeGrotenhuis, W. E.; Wegeng, R. S.; Pederson, L. R. 'Microchannel reactors for fuel processing applications. II. Compact fuel vaporization for fuel cells' AIChE Spring Meeting 2002 / DOE technical report; Air Products / PNNL CRADA 2002–2008; US7186388B2; AIChE Process Intensification Award presentation 2007
- **ip status**: patented
- **prior art notes**: The PNNL/Air Products CRADA work in 2002–2008 produced foundational US patents on microchannel steam-methane reforming for distributed hydrogen production. Discloses (a) integration of SMR + water-gas-shift catalyst beds in adjacent microchannel layers within a single diffusion-bonded laminate reactor block; (b) integrated combustion channels providing endothermic-reaction heat in cross-flow arrangement; (c) sized for distributed (refueling-station-scale) hydrogen production. Anticipates patent claims directed to integrated SMR+WGS microchannel modules for distributed hydrogen production. Pairs with Velocys (FT) and Ineratec (PtX) — same diffusion-bonded laminate platform, different chemistry.

## Kobelco SUMC stacked-microchannel-reactor (Sumitomo platform) (2005)

- **id**: `kobelco-sumc-stacked-microchannel-reactor`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Kobe Steel Ltd. (Kobelco)
- **disclosure**: Kobe Steel Ltd. SUMC microchannel reactor product brochure 2005; Yoshida, J.; Kim, H.; Nagaki, A. 'Green and sustainable chemical synthesis using flow microreactors' ChemSusChem 2011, 4, 331–340 (cites SUMC); JP4438168 Kobe Steel patent 2005
- **ip status**: patented
- **prior art notes**: Discloses Japanese commercial industrial microreactor platform (Kobelco/Sumitomo) using diffusion-bonded stacked metal plates with sub-millimeter etched channels. Distinct from the Velocys/Ineratec axis (FT/PtX) by targeting fine-chemicals/pharma rather than gas-to-liquids. Provides prior-art evidence of multiple independent commercial implementations of the diffusion-bonded-laminate microreactor pattern in the 2003–2008 window. Anticipates patent claims to diffusion-bonded stacked-plate microreactors for high-pressure exothermic chemistry.

## BioFire FilmArray multiplex PCR cartridge (2008)

- **id**: `biofire-filmarray-multiplex-pcr-cartridge`
- **corpus**: private
- **device class**: point-of-care-cartridge
- **creator**: BioFire Diagnostics (Idaho Technology origin); BioMérieux subsidiary
- **disclosure**: Idaho Technology Inc. (now BioFire Diagnostics, BioMérieux). FilmArray system. FDA 510(k) clearances K103175 (2011) and subsequent panels.
- **ip status**: patented
- **prior art notes**: Discloses a single-use disposable cartridge integrating sample preparation, nucleic acid extraction, multiplex nested PCR, and array-based detection in a closed pouch format. Anticipates: blister-pack on-cartridge reagent storage, foil-piercing actuation, multilayer thermoplastic lamination as a fabrication path for point-of-care molecular diagnostics, integrated thermal cycling within a sealed pouch, and the architectural pattern of 'sample-in / answer-out' multiplex IVD cartridges. The dominant commercial implementation in syndromic panel testing.

## Lonza FlowPlate microreactor (with Ehrfeld BTS) (2008)

- **id**: `lonza-flowplate`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Lonza AG (Visp, CH) in collaboration with Ehrfeld Mikrotechnik BTS
- **disclosure**: Roberge, D. M.; Zimmermann, B.; Rainone, F.; Gottsponer, M.; Eyholzer, M.; Kockmann, N. 'Microreactor technology and continuous processes in the fine chemical and pharmaceutical industry: is the revolution underway?' Org. Process Res. Dev. 2008, 12, 905–910; Lonza/Ehrfeld FlowPlate product brochure 2008–2010; EP1762298B1
- **ip status**: patented
- **prior art notes**: Discloses (a) the Lonza A6 plate family — a standardized series of stainless-steel microreactor plates with sickle/comma-shape mixing geometry, sized to span screening (0.3 mL) through pilot (45 mL) through production (1500 mL); (b) explicit benchmarking of mixing efficiency by Villermaux–Dushman protocol allowing apples-to-apples comparison with Corning AFR, Chemtrix Plantrix, etc.; (c) the architectural pattern of 'numbering up at every scale level' rather than scaling channel geometry. Provides additional prior art alongside Corning, Chemtrix, Ehrfeld for the broader claim that industrial microreactors with standardized scalable plate families were widely commercialized 2007–2010.

## Alfa Laval ART Plate Reactor (Reaction Technology) (2008)

- **id**: `alfa-laval-art-plate-reactor`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Alfa Laval AB
- **disclosure**: Alfa Laval ART Plate Reactor product brochure 2008–2010; Anxionnaz, Z.; Cabassud, M.; Gourdon, C.; Tochon, P. 'Heat exchanger/reactors (HEX reactors): Concepts, technologies: State-of-the-art' Chem. Eng. Process. 2008, 47, 2029–2050; Alfa Laval datasheet 'ART Plate Reactor' rev 2014
- **ip status**: patented
- **prior art notes**: Discloses the heat-exchanger-reactor (HEX-R) variant of microreactor: a brazed plate stack with channel hydraulic diameter ~2–5 mm (technically 'meso' rather than micro) but designed with same heat-removal-per-unit-volume performance as Corning AFR and Lonza FlowPlate. Anticipates: (a) plate-stack HEX reactors derived from compact-heat-exchanger architectures; (b) multi-injection-port plate reactors for stage-wise reagent addition along a single reaction channel; (c) integration of plant-grade gasketed sealing into continuous-flow chemistry plants. Important counterpoint to true sub-millimeter microreactors that broadens the prior-art commons against future patents claiming 'compact plate reactor for continuous chemistry'.

## PowerCell Sweden microchannel fuel processor reformer (2008)

- **id**: `powercell-microchannel-fuel-cell-reformer`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: PowerCell Sweden AB (Gothenburg, SE; Volvo spinout)
- **disclosure**: PowerCell Sweden AB founding 2008 (Volvo SOFC spinout); Karlsson, P.; Lundberg, J.; Sjöstrand, M. 'Diesel-fueled SOFC APU using a microchannel reformer' SAE Technical Paper 2011-01-2271, 2011; PowerCell datasheet rev 2018; Volvo Powertrain microchannel reformer prior art DE19712114A1 1997
- **ip status**: patented
- **prior art notes**: Discloses a diffusion-bonded stainless-steel microchannel autothermal reformer with catalyst-coated reaction channels and parallel combustion channels for in-situ heating, sized for vehicle-APU SOFC integration. Anticipates patent claims directed to integrated microchannel reformer-combustor architectures for distributed hydrogen production. Pairs with Velocys (FT side) and Air Products (steam reforming) to broadly cover the microchannel-reformer prior art.

## ALine integrated multilayer flow cells (laminate microfluidics) (2010)

- **id**: `aline-integrated-flowcell`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: ALine Inc.
- **disclosure**: ALine Inc. integrated multilayer microfluidic flow cells. https://alineinc.com/. ALine Inc. founded 2002 as a contract designer / manufacturer for laminate-based microfluidic devices.
- **ip status**: patented
- **prior art notes**: Lamination-based microfluidic manufacturing: stacked laser-cut PMMA / COC layers with pressure-sensitive-adhesive interlayers form integrated flow cells, including embedded blister reagent pouches and burst valves. Anticipates: PSA-laminate manufacturing as a third major microfluidic fabrication process category alongside soft lithography and thermoplastic injection molding; the architectural pattern of a CRO/CDMO providing both prototyping and production-scale runs of laminate flow cells. Many commercial diagnostic cartridges (including OEM cards inside larger systems) are ALine-built or ALine-architected.

## Aerosint Selective Multi-Powder Deposition Recoater (2016)

- **id**: `aerosint-selective-powder-deposition`
- **corpus**: private
- **device class**: printer-tooling
- **creator**: Aerosint SA (Herstal, Belgium); subsequently Desktop Metal; now Schaeffler Special Machinery
- **disclosure**: Aerosint SA founding 2016 (Herstal, Belgium); patent EP3393689B1 / US patents on selective powder deposition; aerosint.com/about/
- **ip status**: patented
- **prior art notes**: Discloses a recoater architecture for additive manufacturing in which one or more rotating drums each carry a single powder material and selectively release particles in a programmed pattern as the drum traverses the build area, enabling multiple powder materials to be co-deposited in a single layer. Anticipates: (a) the SPD class of multi-powder recoaters as an upstream partner to binder-jet and L-PBF systems, (b) drum-based programmable powder release as an alternative to per-feed-line powder switching, (c) line-by-line patterning rates compatible with industrial AM process windows. Predicate to subsequent multi-material binder-jet machines and to Schaeffler's industrial powder-bed multi-material systems.

## Ineratec PtX microreactor for e-fuels and Power-to-Liquid (2016)

- **id**: `ineratec-ptx-microreactor`
- **corpus**: private
- **device class**: lab-on-chip
- **creator**: Ineratec GmbH (KIT spinout)
- **disclosure**: Ineratec GmbH founding 2016 from Karlsruhe Institute of Technology spinout; Loewert, M.; Pfeifer, P. 'Microstructured Fischer-Tropsch reactor scale-up and opportunities for decentralized application' Chem. Ing. Tech. 2020, 92, 696–708; Ineratec product release 'P2X container' 2018; INERATEC Atmosfair pilot plant commissioning 2021 Werlte, Germany
- **ip status**: patented
- **prior art notes**: Direct descendant of Velocys's microchannel-FT architecture, but optimized for e-fuel/PtX rather than gas-to-liquids: (a) discloses containerized modular packaging of microchannel FT and methanol synthesis plus reverse-water-gas-shift (RWGS) into shipping-container-sized standardized modules suitable for distributed deployment at hydrogen production sites; (b) discloses CO2-feedstock-compatible catalyst formulations and the integrated RWGS-FT process intensification within a microchannel block; (c) commercial demonstration at Werlte, Germany. Anticipates patent claims directed to containerized microchannel e-fuel plants and to integrated RWGS-FT microchannel reactor blocks.
