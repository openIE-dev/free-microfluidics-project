---
title: heated-blanket-water-flash-off
parent: Cross-cuts
layout: default
---

# Cross-cut: `heated-blanket-water-flash-off`

**2 corpus entries disclose this subsystem.**

Earliest disclosure: 2018

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## Landa S10 Nanographic Sheetfed Press (2018)

- **id**: `landa-s10-nanographic-press`
- **corpus**: private
- **device class**: inkjet-printhead
- **creator**: Landa Corporation (Benny Landa)
- **disclosure**: Landa S10 launch drupa 2012 (concept), commercial shipment 2018; Landa Corporation S10 datasheet
- **ip status**: patented
- **prior art notes**: Landa's flagship nanographic press. Discloses the full nanographic architectural primitive: (1) NanoInk - aqueous pigment dispersion with sub-100nm pigment particles enabling ultra-thin transferred films; (2) inkjet-onto-blanket rather than inkjet-onto-paper, with the blanket heated to flash off water; (3) mechanical transfer from blanket to substrate at the impression nip; (4) the resulting print sits on top of the substrate rather than absorbing into it, enabling print on any stock. Anticipates: a wide swath of indirect-transfer inkjet press claims, particularly the use of a heated intermediate blanket as the imaging surface in a digital-offset hybrid. Foundational to the entire nanographic process category.

## Landa W10 Nanographic Web Press (2018)

- **id**: `landa-w10-nanographic-web-press`
- **corpus**: private
- **device class**: inkjet-printhead
- **creator**: Landa Corporation
- **disclosure**: Landa W10 launch drupa 2016, commercial shipment 2018; Landa W10 datasheet
- **ip status**: patented
- **prior art notes**: Web-press variant of Landa S10 nanographic technology. Same architectural primitives (NanoInk + heated blanket + indirect transfer) but applied to continuous web transport rather than cut sheet. Anticipates: web-fed nanographic presses for publishing and flexible packaging applications.
