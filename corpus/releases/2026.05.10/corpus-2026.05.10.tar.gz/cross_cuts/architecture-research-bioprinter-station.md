---
title: architecture-research-bioprinter-station
parent: Cross-cuts
layout: default
---

# Cross-cut: `architecture-research-bioprinter-station`

**1 corpus entries disclose this subsystem.**

Earliest disclosure: 2002

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## MicroFab Jetlab 4 Life-Sciences Inkjet Print Station (2002)

- **id**: `microfab-jetlab-4-life-sciences-printer`
- **corpus**: private
- **device class**: dispenser-pipettor
- **creator**: MicroFab Technologies, Inc. (Plano, TX)
- **disclosure**: MicroFab Technologies Jetlab II launch 2002; Jetlab 4 datasheet 2008; Jetlab 4xl extended-stage datasheet 2014
- **ip status**: patented
- **prior art notes**: Extends wave 1 microfab-mj-at coverage with the integrated Jetlab printer station. Architectural primitives: integration of the MJ-AT piezo glass-capillary dispenser onto an XYZ-positioning stage with synchronized strobe imaging for in-situ jet calibration; multi-printhead capability for simultaneous parallel deposition of different fluids (e.g., one printhead per ink). Anticipates: research-grade life-sciences inkjet print stations using glass-capillary piezo microdispensers on XYZ stages with strobed drop verification. Foundational instrument in academic bioprinting and microarray research.
